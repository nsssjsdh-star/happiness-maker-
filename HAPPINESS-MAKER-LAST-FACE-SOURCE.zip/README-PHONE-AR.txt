HAPPINESS MAKER — The Last Face

هذا الملف مجهز للعمل من الهاتف.

المشروع الرئيسي موجود داخل:
react-phaser-game/

إذا كنت سترفع ZIP واحدا إلى GitHub، يجب إنشاء ملف Workflow صغير داخل GitHub لأن GitHub لا يفك ZIP تلقائيا عند رفعه.

استعمل محتوى BUILD_WORKFLOW.yml.txt لإنشاء الملف:
.github/workflows/build.yml

بعدها ارفع ZIP إلى المستودع واضغط Actions ثم Run workflow.

الناتج سيكون نسخة الويب داخل Artifacts باسم:
HAPPINESS-MAKER-LAST-FACE-web
