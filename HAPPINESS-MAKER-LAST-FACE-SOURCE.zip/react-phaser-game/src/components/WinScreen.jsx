import React from 'react'
import './WinScreen.css'
export function WinScreen({ message }) {
  return <div className="win-screen-overlay" dir="rtl"><div className="win-content"><div className="win-icon">✓</div><h1>نجحتي!</h1><p className="win-message">{message || 'كشفتي الحقيقة قبل ما يضيع الدوّار.'}</p><button className="reset-button" onClick={() => window.location.reload()}>عاود اللعب</button></div></div>
}
