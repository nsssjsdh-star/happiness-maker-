import React from 'react'
import './FailScreen.css'
export function FailScreen({ message }) {
  return <div className="fail-screen-overlay" dir="rtl"><div className="fail-content"><div className="fail-icon">☠</div><h1>سالـى التحقيق</h1><p>{message || 'الظلام ربح هاد المرة.'}</p><button className="restart-button" onClick={() => window.location.reload()}>عاود من الأول</button></div></div>
}
