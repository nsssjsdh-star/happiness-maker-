import React from 'react'
import { useGameStore } from '../store/gameStore'
import './Sidebar.css'

export default function Sidebar() {
  const { cycle, houses } = useGameStore()
  const getContext = (day) => {
    if (day === 1) return 'كريم اختفى. كاين خوف فالدّوار، وكل واحد ممكن يكون عارف أكثر مما كيقول.'
    if (day === 2) return 'ياسين تلقاوه ميت... ولكن شي ناس كيقسمو أنهم هضرو معاه البارح.'
    if (day === 3) return 'مريم ماتت. كاين واحد وسطكم كيتعلم كيفاش يقلد الناس.'
    if (day === 4) return 'بقاو غير جوج. دابا خاصك تعرف شكون الحقيقي قبل ما يفوت الوقت.'
    return 'الليل مازال طويل...'
  }
  const clues = houses.filter(h => h.status === 'dead' || h.status === 'missing').map(h => {
    if (h.status === 'missing') return 'كريم ما زال مفقوداً. آخر أثر كان قرب الغابة.'
    return `دار ${h.npc?.name || 'واحد من السكان'} تبدلات حالتها بشكل غريب.`
  })
  return (
    <aside className="sidebar-container" dir="rtl">
      <div className="sidebar-brand">HAPPINESS MAKER</div>
      <h1 className="sidebar-title">📁 ملف التحقيق</h1>
      <div className="day-context">
        <div className="day-header">الليلة {cycle}</div>
        <p>{getContext(cycle)}</p>
      </div>
      <div className="journal-section">
        <h2 className="journal-header">🔎 ملاحظات</h2>
        <div className="journal-list">
          {clues.length === 0 ? <p className="empty-note">مازال ما جمعتي حتى دليل.</p> : clues.map((entry, idx) => <div key={idx} className="journal-entry">{entry}</div>)}
        </div>
      </div>
      <div className="controls-hint">🖱️ كليك على الديور • ⌨️ الأسهم/WASD • E أو Space للتفاعل</div>
    </aside>
  )
}
