import React, { useState } from 'react'
import { useGameStore } from '../store/gameStore'
import './IntroScreen.css'

export function IntroScreen() {
  const [visible, setVisible] = useState(true)
  const { initSession } = useGameStore()
  if (!visible) return null
  const handleStart = () => { initSession(); setVisible(false) }
  return (
    <div className="intro-overlay" dir="rtl">
      <div className="intro-content">
        <div className="brand-mark">HAPPINESS MAKER</div>
        <h1>الوجه الأخير</h1>
        <div className="intro-subtitle">ملفّات الدوّار المنسي</div>
        <div className="intro-text">
          <p>فدوّار معزول، كريم اختفى بلا أثر.</p>
          <p>ومن بعد الاختفاء، بداو الناس كيموتو بطريقة ما مفهومةش.</p>
          <p>المشكل الحقيقي؟ شي حاجة كتقدر تلبس وجه بنادم وتعيش وسط الناس.</p>
          <p>هضر مع السكان، قلب على التناقضات، وركّز فكل تفصيل.</p>
          <p className="warning">⚠️ ماشي كل وجه كتشوفو هو الوجه الحقيقي.</p>
        </div>
        <button className="intro-button" onClick={handleStart}>ابدأ التحقيق</button>
        <div className="intro-tip">اللعبة خدامة بلا سيرفر وبلا حساب وبلا API مدفوع.</div>
      </div>
    </div>
  )
}
