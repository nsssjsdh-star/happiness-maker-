import React, { useState, useEffect, useRef } from 'react'
import { useGameStore } from '../store/gameStore'
import { gameApi } from '../services/api'
import './ConversationDialog.css'

export function ConversationDialog() {
  const { currentHouse, closeHouseMenu, sessionId, cycle } = useGameStore()
  const [currentNode, setCurrentNode] = useState(null)
  const [chatHistory, setChatHistory] = useState([])
  const [chatInput, setChatInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const chatEndRef = useRef(null)
  const isVillager = currentHouse?.type === 'villager'

  useEffect(() => {
    if (!currentHouse) return
    setChatHistory([])
    setChatInput('')
    if (!isVillager) {
      const dayKey = `day${cycle}`
      if (currentHouse[dayKey]?.npc?.dialog?.length) setCurrentNode(currentHouse[dayKey].npc.dialog[0])
      else if (currentHouse.npc?.dialog?.length) setCurrentNode(currentHouse.npc.dialog[0])
      else setCurrentNode(null)
    }
  }, [currentHouse, isVillager, cycle])

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chatHistory])
  if (!currentHouse) return null

  if (['infected', 'dead', 'missing'].includes(currentHouse.status)) {
    const npcName = currentHouse.npc?.name || 'المكان'
    let overlayText = ''
    if (currentHouse.status === 'dead') overlayText = `${npcName}... شي حاجة ماشي طبيعية. الجثة باينة عليها ماتت قبل أكثر من نهار، مع أن الناس شافوه البارح.`
    if (currentHouse.status === 'missing') overlayText = 'دار كريم... الدليل الوحيد اللي بقا هو هاد الدائرة الغريبة. شكون دارها؟'
    if (currentHouse.status === 'infected') overlayText = `كاين شي حاجة ماشي طبيعية فـ ${npcName}...`
    return <div className="infected-overlay" onClick={closeHouseMenu} dir="rtl"><div className="infected-content">{currentHouse.infectedImage && <img src={currentHouse.infectedImage} alt="دليل مرعب" className="infected-image-fullscreen" />}{overlayText && <p className="infected-overlay-text">{overlayText}</p>}<span className="tap-close">كليك باش تسد</span></div></div>
  }

  const handleOption = (option) => {
    if (option.action === 'sleep') return useGameStore.getState().sleep()
    if (option.action === 'eliminate') { useGameStore.getState().setEliminationMode(true); closeHouseMenu(); return }
    if (option.action === 'close') return closeHouseMenu()
    if (option.nextDialog) setCurrentNode(option.nextDialog)
    else if (option.response) setCurrentNode({ text: option.response, options: [{ label: 'سد الحوار', action: 'close' }] })
  }

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (!chatInput.trim() || isLoading) return
    const userMsg = chatInput.trim()
    setChatHistory(prev => [...prev, { sender: 'user', text: userMsg }])
    setChatInput(''); setIsLoading(true)
    const charName = currentHouse.npc?.name || 'مشتبه فيه'
    const data = await gameApi.interrogate(sessionId, charName, userMsg, cycle)
    setIsLoading(false)
    setChatHistory(prev => [...prev, { sender: 'npc', text: data?.response || 'ما جاوبكش...' }])
  }

  const npc = currentHouse.npc
  const npcName = npc?.name || 'مشتبه فيه'
  const latestNpcMessage = chatHistory.filter(m => m.sender === 'npc').slice(-1)[0]?.text || 'سولني... يمكن نغلط فشي كلمة.'

  if (isVillager) return (
    <div className="conversation-overlay" dir="rtl">
      <div className="conversation-dialog-box">
        <div className="dialog-left">
          {npc?.portrait ? <img src={npc.portrait} alt={npcName} className="dialog-portrait" /> : <div className="dialog-portrait-placeholder"><span>🏚️</span></div>}
        </div>
        <div className="dialog-right">
          <div className="dialog-response-area">
            <div className="dialog-tag">شخصية قيد التحقيق</div>
            <h3 className="dialog-npc-name">{npcName}</h3>
            <div className="dialog-response-text">{isLoading ? <em>كيقلب على الجواب...</em> : <p>{latestNpcMessage}</p>}</div>
            {chatHistory.slice(-4).map((m, i) => <div key={i} className={`chat-mini ${m.sender}`}>{m.text}</div>)}
            <div ref={chatEndRef} />
          </div>
          <div className="dialog-input-area">
            <form onSubmit={handleSendMessage} className="dialog-input-form">
              <input dir="rtl" type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.stopPropagation()} placeholder="كتب السؤال ديالك هنا..." className="dialog-input" disabled={isLoading} autoFocus />
              <div className="dialog-buttons"><button type="submit" disabled={isLoading} className="dialog-btn dialog-btn-ask">سول</button><button type="button" onClick={closeHouseMenu} className="dialog-btn dialog-btn-leave">خرج</button></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )

  return <div className="conversation-overlay" dir="rtl"><div className="conversation-box"><div className="dialog-tag">دار الحارس</div><h2 className="npc-name">{npcName}</h2><div className="dialog-text">{currentNode?.text || '...'}</div><div className="options-list">{currentNode?.options?.map((option, index) => <button key={index} className="dialog-option" onClick={() => handleOption(option)}>{option.label}</button>)}</div></div></div>
}
