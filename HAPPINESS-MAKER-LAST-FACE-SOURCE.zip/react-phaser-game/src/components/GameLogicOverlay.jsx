import React from 'react'
import { useGameStore } from '../store/gameStore'
import { FailScreen } from './FailScreen'
import { WinScreen } from './WinScreen'

export function GameLogicOverlay() {
  const { houses, hasWon, hasLost, eliminationMode, eliminateVillager, setEliminationMode, endGameMessage, cycle } = useGameStore()
  if (hasWon) return <WinScreen message={endGameMessage} />
  if (hasLost) return <FailScreen message={endGameMessage} />
  const normalCount = houses.filter(h => h.type === 'villager' && h.status === 'normal').length
  if ((normalCount <= 1 && !hasWon) || (cycle > 4 && normalCount >= 2)) return <FailScreen message="المخلوق ربح... والدوّار ضاع." />
  if (!eliminationMode) return null
  const survivors = houses.filter(h => h.type === 'villager' && h.status === 'normal')
  return (
    <div className="elimination-overlay" dir="rtl">
      <div className="elimination-content">
        <div className="case-label">قرار مصيري</div>
        <h2>شكون هو المخلوق؟</h2>
        <p>إلى غلطتي، التحقيق كيسالي هنا.</p>
        <div className="suspect-list">
          {survivors.map(h => <button key={h.id} className="suspect-btn" onClick={() => eliminateVillager(h.id)}>{h.npc?.name || 'مشتبه فيه'}</button>)}
        </div>
        <button className="cancel-btn" onClick={() => setEliminationMode(false)}>رجع</button>
      </div>
    </div>
  )
}
