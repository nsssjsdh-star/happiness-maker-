// النسخة المجانية: ما كاين حتى سيرفر خارجي ولا API مدفوع.
// المحادثة هنا محلية باش اللعبة تبقى خدامة حتى بلا إنترنت.

const localReplies = {
  "إسماعيل — الطحّان": [
    "ما بغيتش نهضر بزاف... من نهار اختفى كريم وأنا ما بقيتش كنرتاح.",
    "إلا بغيتي الحقيقة، راقب اللي تبدل سلوكو فجأة.",
    "سمعت صوت فالغابة البارح... وما كانش صوت بنادم."
  ],
  "أمينة — العشّابة": [
    "كريم كان خايف، وكان كيهضر على الجلد والاسم ديالو.",
    "أنا كنلاحظ التفاصيل الصغيرة... خصوصاً اللي كتبدل فنهار واحد.",
    "ماشي كل جرح كيكون من حيوان."
  ],
  "ياسين — الصيّاد": [
    "ما عنديش وقت لهاد الهضرة.",
    "الغابة كتخبي أسرار أكثر مما كتخبي من الحيوانات.",
    "إلا بغيتي تبقى حي، ما تثقش بسرعة."
  ],
  "مريم — الخيّاطة": [
    "أنا بخير... أو هكذا كنظن.",
    "كاين شي حاجة فهاد الدوار كتخليني نحس بالبرد حتى حد العافية.",
    "سولني على الثوب... يمكن نقدر نعاونك."
  ],
  "الحاج عمر": [
    "العين كتقدر تخدعك، ولكن التصرفات صعيب تخبيها.",
    "اللي كيتبدل بين ليلة ونهار، خاصك توقف عندو.",
    "الليل ما كيخليش الأسرار مخبية للأبد."
  ]
}

export const gameApi = {
  createSession: async () => ({ session_id: `local-${Date.now()}` }),
  advanceDay: async () => ({ ok: true }),
  eliminate: async (_sessionId, character, day) => {
    const skinwalker = { 1: "ياسين — الصيّاد", 2: "مريم — الخيّاطة", 3: "الحاج عمر", 4: "إسماعيل — الطحّان" }[day] || "إسماعيل — الطحّان"
    if (character === skinwalker) {
      return { result: "win", message: "لقيتيه! كان هو اللي كيتقمص الوجوه. الدوار نجا... هاد المرة." }
    }
    return { result: "lose", message: "غلطتي فالاتهام. المخلوق ما زال حر... والليل ما سالاش." }
  },
  interrogate: async (_sessionId, character, message, day) => {
    const replies = localReplies[character] || ["الجواب ما واضحش... خاصك تقلب على دليل آخر."]
    const lower = message.toLowerCase()
    let index = (message.length + day) % replies.length
    if (lower.includes("كريم") || lower.includes("اختفى")) index = 0
    if (lower.includes("خوف") || lower.includes("خايف")) index = Math.min(1, replies.length - 1)
    if (lower.includes("دليل") || lower.includes("سر")) index = replies.length - 1
    return { response: replies[index] }
  }
}
