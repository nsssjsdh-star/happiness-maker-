// بيانات اللعبة — النسخة العربية/الدارجة
const createDialog = (text, options = []) => ({ text, options })

const chat = { label: "🔎 حقّق أكثر", action: "chat" }

const day1_1 = createDialog("جيتي كتقلب على كريم، ماشي هكا؟", [
  { label: "فاش شفتي كريم آخر مرة؟", response: "البارح مع الغروب، كان قريب للغابة." , nextDialog: createDialog("البارح مع الغروب، كان قريب للغابة.", [
    { label: "كان بوحدو؟", response: "آه... ولكن كان كيشوف لياسين بطريقة غريبة." },
    { label: "علاش ياسين؟", response: "ما عرفت. ياسين حتى هو تصرف بحال إلا ما كيعرفوش." }
  ])},
  { label: "كيفاش باين ليك ياسين؟", response: "غريب. ديما كيكون هادئ، ولكن اليوم كيراقب كلشي.", nextDialog: createDialog("كيراقب؟", [
    { label: "كيراقب شكون؟", response: "كل واحد فينا... بحال شي ذيب كيتسنى الفريسة." }
  ])},
  { label: "صافي، شكراً.", response: "رد بالك من الغابة فالليل." }, chat
])

const day1_2 = createDialog("كريم اختفى... الله يلطف به.", [
  { label: "عالجتيه قبل ما يختفي؟", response: "آه. جا عندي وهو خايف من شي حاجة.", nextDialog: createDialog("خايف من شنو؟", [
    { label: "من راسو؟", response: "لا. قال ليا: 'الجلد ما بقاش ديالي'." }
  ])},
  { label: "شفتي ياسين؟", response: "دوز من حدانا وما سلمش عليا.", nextDialog: createDialog("واش هادي ماشي عادية؟", [
    { label: "علاش؟", response: "حيت عمره ما دارها. اليوم داز قدامي بحال إلا ما شافنيش." }
  ])},
  { label: "ردي بالك على راسك.", response: "ديما كنرد البال." }, chat
])

const day1_3 = createDialog("شنو بغيتي آ الحارس؟", [
  { label: "فين كنت البارح بالليل؟", response: "فالغابة، كنقلب على الصيد.", nextDialog: createDialog("كتقلب على شنو؟", [
    { label: "شي حيوان؟", response: "على اللحم الطري... ماشي وقت الأسئلة الكثيرة." }
  ])},
  { label: "شفتي كريم؟", response: "كريم؟ راه اختفى. كان ضعيف بزاف.", nextDialog: createDialog("ما باينش عليك خايف عليه.", [
    { label: "علاش؟", response: "فالدوّار، اللي ضعيف خاصو يبقى حذر." }
  ])},
  { label: "راك مختلف اليوم.", response: "يمكن غير نتا اللي بديتي كتشوف مزيان." },
  { label: "صافي.", response: "سير فحالك." }, chat
])

const day1_4 = createDialog("علاش كتشوف فيا هكا؟", [
  { label: "غير كنطرح الأسئلة.", response: "ياسين كان واقف حدّ الشرجم ديالي البارح.", nextDialog: createDialog("كيـدير شنو؟", [
    { label: "والو؟", response: "والو... غير واقف وكيتنفس. هادي هي اللي خوفتني." }
  ])},
  { label: "واش نتي بخير؟", response: "بردانة حتى حدّ العافية. ما عرفت علاش." },
  { label: "سدي الباب مزيان.", response: "غادي نسدو دابا." }, chat
])

const day1_5 = createDialog("الهواء اليوم فيه ريحة الموت.", [
  { label: "يمكن غير ريحة الغابة.", response: "لا. هادي ريحة موت قديم... مخبي تحت شي حاجة جديدة.", nextDialog: createDialog("مخبي تحت شنو؟", [
    { label: "تحت جلد جديد.", response: "بالضبط. ما تثقش فالعينين ديالك." }
  ])},
  { label: "رتاح آ الحاج.", response: "ما بقى حتى وقت للراحة." }, chat
])

const day2_1 = createDialog("شفتو! شفتو بعيني! شفتو البارح!", [
  { label: "هدا راسك... شكون؟", response: "ياسين! هضر معايا وضحك معايا!", nextDialog: createDialog("هضر معاك؟", [
    { label: "شنو قال؟", response: "قال ليا: 'الطحين اليوم زوين'. ولكن الطبيب كيقول راه ميت من مدة!" },
    { label: "واش متأكد؟", response: "إلا ما شفتوش بعيني، كون قلت كنحلم." }
  ])},
  { label: "إلا كان ميت...", response: "إيوا شكون كان فدارو؟!" , nextDialog: createDialog("شي حاجة ماشي بنادم.", [
    { label: "شنو هي؟", response: "كتلبس وجوه الناس... وكتعيش بيناتنا." }
  ])},
  { label: "بقا فالدار.", response: "ما غاديش نخرج." }, chat
])

const day2_2 = createDialog("هادشي ما داخلش للعقل.", [
  { label: "شرح ليا شنو لقيتي.", response: "جثة ياسين كانت متحللة بزاف.", nextDialog: createDialog("شحال كان ميت؟", [
    { label: "تقريباً؟", response: "على الأقل 48 ساعة... يعني قبل البارح." },
    { label: "ولكن هضرنا معاه.", response: "هضرنا مع الجلد ديالو... ماشي مع ياسين." }
  ])},
  { label: "يعني اللي شفناه كان شنو؟", response: "شي مخلوق كيتقمص الناس. واليوم راه وسطنا." },
  { label: "غادي نقلب عليه.", response: "قلب على اللي تبدل فجأة." }, chat
])

const day2_4 = createDialog("الصباح زوين اليوم، ماشي؟", [
  { label: "نتي فرحانة بزاف.", response: "علاش لا؟ الشمس دافية.", nextDialog: createDialog("ولكن ياسين مات.", [
    { label: "آه؟", response: "الناس كيموتو... هادي هي الحياة." },
    { label: "البارح كنتي خايفة بزاف.", response: "كنت؟ ما بقاتش فيا نفس الخوف اليوم." }
  ])},
  { label: "شنو كتخدمي؟", response: "شي ثوب... للحفلة.", nextDialog: createDialog("وعلاش ما كتقدريش تشرحي ليا النقشة؟", [
    { label: "حيت نسيتي؟", response: "يمكن... غير خيوط وخلاص." }
  ])},
  { label: "بقا هنا.", response: "غادي نبقى." }, chat
])

const day2_5 = createDialog("الشيء اللي كيقلب على وجوهنا بدّل الجلد.", [
  { label: "ياسين كان هو الضحية؟", response: "كان غير واحد من الوجوه اللي استعملها." },
  { label: "ودابا شكون؟", response: "سمع للصوت... للهدرة... للخوف اللي كيبان ولا ما كيبانش.", nextDialog: createDialog("شنو خاصني نلاحظ؟", [
    { label: "التغيير اللي كيوقع فنهار واحد.", response: "الخوف الحقيقي ما كيمشيش فليلة وحدة." }
  ])},
  { label: "غادي نلقاه.", response: "سرّع قبل ما يجي الليل." }, chat
])

const day3_1 = createDialog("مريم... ماشي مريم.", [
  { label: "مريم ماتت.", response: "ماتت من جوج أيام... جوج أيام!" },
  { label: "ولكن هضرت معاها البارح.", response: "إيوا داكشي اللي هضرتي معاه ما كانش هي." }
])
const day3_2 = createDialog("نفس النمط كيتعاود.", [
  { label: "مريم؟", response: "الجثة كانت ميتة قبل البارح. وما بقى فيها والو." },
  { label: "شي حاجة كانت كتقلدها؟", response: "آه. وحتى أبسط تفاصيل حياتها ما عرفاتهاش." }
])
const day3_5 = createDialog("جوج وجوه تبدلو.", [
  { label: "شكون بقا؟", response: "غير اللي ما زال قادر يوقف قدام هاد الشي." },
  { label: "واش نتا هو؟", response: "إلا كنت هو، ما كنتيش غادي تبقى كتهضر دابا." }
])
const day4_1 = createDialog("واش نتا هو؟ ولا أنا؟", [
  { label: "الحاج عمر مات.", response: "بقاو غير جوج... أنا ونتا." },
  { label: "واحد فينا هو المخلوق.", response: "عارف. وأنا حتى أنا كنراقبك." }, chat
])
const day4_2 = createDialog("هادي هي آخر تجربة.", [
  { label: "بقاو غير جوج.", response: "آه. والشيء اللي كيقلب على وجوهنا واحد فينا." },
  { label: "كيفاش نعرفو؟", response: "ما عنديش الجواب... وهادشي هو اللي مخيف." }, chat
])

export const houses = [
  { id:"house_corin", type:"villager", x:1500,y:210,image:"house4",status:"missing",altImage:"house4-infected",infectedImage:"assets/first-house.png",npc:{name:"دار كريم",portrait:null,dialog:[]} },
  { id:"guard_house", type:"guard", x:860,y:280,image:"house5",status:"normal",npc:{name:"الحارس — نتا",portrait:"assets/male1_mod.png",dialog:[{text:"الليل قرب يطيح... واش بغيتي ترتاح حتى للصباح؟",options:[{label:"😴 نعس حتى للصباح",action:"sleep",response:"الله يحفظك."},{label:"🔪 اتهم شي واحد",action:"eliminate",response:"شكون كتشُك فيه؟"},{label:"رجع",action:"close",response:"رد بالك."}]}]}},
  { id:"house_1",type:"villager",x:80,y:1100,image:"house2",status:"normal",altImage:"house2-infected",infectedImage:"assets/murder-house1.png",day1:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day1_1]}},day2:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day2_1]}},day3:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day3_1]}},npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day1_1]}},
  { id:"house_2",type:"villager",x:80,y:450,image:"house1",status:"normal",altImage:"house1-infected",infectedImage:"assets/murder-house2.png",day1:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day1_2]}},day2:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day2_2]}},day3:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day3_2]}},npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day1_2]}},
  { id:"house_3",type:"villager",x:1490,y:700,image:"house3",status:"normal",altImage:"house3-infected",infectedImage:"assets/murder-house3.png",day1:{npc:{name:"ياسين — الصيّاد",portrait:"assets/male2_mod.png",dialog:[day1_3]}},day2:{npc:null,status:"dead",infectedImage:"assets/murder-house3.png"},day3:{npc:null,status:"dead",infectedImage:"assets/murder-house3.png"},npc:{name:"ياسين — الصيّاد",portrait:"assets/male2_mod.png",dialog:[day1_3]}},
  { id:"house_4",type:"villager",x:1300,y:1100,image:"house6",status:"normal",altImage:"house6-infected",infectedImage:"assets/murder-house1.png",day1:{npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day1_4]}},day2:{npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day2_4]}},day3:{npc:null,status:"dead",infectedImage:"assets/murder-house2.png"},npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day1_4]}},
  { id:"house_5",type:"villager",x:900,y:800,image:"house7",status:"normal",altImage:"house7-infected",infectedImage:"assets/murder-house2.png",day1:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day1_5]}},day2:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day2_5]}},day3:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day3_5]}},npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day1_5]}}
]
