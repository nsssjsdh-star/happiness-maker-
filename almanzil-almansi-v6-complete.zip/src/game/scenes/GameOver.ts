import { Scene } from 'phaser';

export class GameOver extends Scene {
    constructor() { super('GameOver'); }
    create(data: { reason?: 'caught' | 'escaped' } = {}): void {
        const w = this.scale.width; const h = this.scale.height;
        this.cameras.main.setBackgroundColor('#030406');
        this.add.image(w / 2, h / 2, 'menu-bg').setDisplaySize(w, h).setAlpha(0.25);
        this.add.rectangle(w / 2, h / 2, w, h, 0x020304, 0.72);
        const escaped = data.reason === 'escaped';
        this.add.text(w / 2, 260, escaped ? 'انتهى الفصل الأول…' : 'انتهت الليلة.', { fontFamily: 'Cairo', fontSize: 42, color: '#eee8dd', fontStyle: '800' }).setOrigin(0.5);
        this.add.text(w / 2, 330, escaped ? 'لكن الحقيقة لم تخرج معك.' : 'كان يسمع خطواتك منذ البداية.', { fontFamily: 'Cairo', fontSize: 17, color: '#aaa39a' }).setOrigin(0.5);
        const retry = this.add.text(w / 2, 430, 'إعادة المحاولة', { fontFamily: 'Cairo', fontSize: 17, color: '#15120d', fontStyle: '700', backgroundColor: '#c2aa76', padding: { left: 26, right: 26, top: 12, bottom: 12 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
        retry.on('pointerdown', () => this.scene.start('Game'));
        const menu = this.add.text(w / 2, 500, 'القائمة الرئيسية', { fontFamily: 'Cairo', fontSize: 13, color: '#bdb5a9' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
        menu.on('pointerdown', () => this.scene.start('MainMenu'));
    }
}
