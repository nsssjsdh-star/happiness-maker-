import { Scene } from 'phaser';
import { EventBus } from '../EventBus';

export class MainMenu extends Scene {
    private started = false;
    constructor() { super('MainMenu'); }

    create(): void {
        const w = this.scale.width; const h = this.scale.height;
        this.cameras.main.setBackgroundColor('#020305');
        const bg = this.add.image(w / 2, h / 2, 'menu-bg').setDisplaySize(w, h);
        bg.setAlpha(0.96);
        const shade = this.add.rectangle(w / 2, h / 2, w, h, 0x020305, 0.34);
        const moon = this.add.circle(w * 0.77, h * 0.2, 88, 0xe9e3d3, 0.07);
        this.tweens.add({ targets: moon, scale: 1.07, alpha: 0.1, duration: 2200, yoyo: true, repeat: -1 });

        for (let i = 0; i < 100; i += 1) {
            const x = Phaser.Math.Between(0, w); const y = Phaser.Math.Between(-20, h);
            const drop = this.add.rectangle(x, y, 1, Phaser.Math.Between(10, 28), 0xb9c3ce, Phaser.Math.FloatBetween(0.04, 0.16));
            this.tweens.add({ targets: drop, y: y + Phaser.Math.Between(70, 170), duration: Phaser.Math.Between(650, 1300), repeat: -1, delay: Phaser.Math.Between(0, 1000) });
        }

        this.add.text(w / 2, 108, 'ملف القضية 01', { fontFamily: 'Cairo', fontSize: 13, color: '#b29b70', fontStyle: '700' }).setOrigin(0.5);
        const title = this.add.text(w / 2, 178, 'المنزل المنسي', { fontFamily: 'Cairo', fontSize: 68, color: '#f0ece4', fontStyle: '800', stroke: '#000000', strokeThickness: 10 }).setOrigin(0.5);
        this.add.text(w / 2, 255, 'بعض الأبواب لا تُغلق لحماية من في الداخل…', { fontFamily: 'Cairo', fontSize: 18, color: '#aaa49b' }).setOrigin(0.5);
        this.add.text(w / 2, 285, 'بل لحماية من في الخارج.', { fontFamily: 'Cairo', fontSize: 18, color: '#aaa49b' }).setOrigin(0.5);

        const button = this.add.rectangle(w / 2, 390, 330, 72, 0xbda36d, 1).setStrokeStyle(1, 0xe6d5ad, 0.9).setInteractive({ useHandCursor: true });
        const label = this.add.text(w / 2, 390, 'بدء التحقيق', { fontFamily: 'Cairo', fontSize: 23, color: '#17140f', fontStyle: '800' }).setOrigin(0.5);
        button.on('pointerover', () => { button.setFillStyle(0xd4bd8e); this.tweens.add({ targets: [button, label], scale: 1.025, duration: 120 }); });
        button.on('pointerout', () => { button.setFillStyle(0xbda36d); this.tweens.add({ targets: [button, label], scale: 1, duration: 120 }); });
        button.on('pointerdown', () => this.startGame());

        const continueBtn = this.add.text(w / 2, 455, 'متابعة آخر حفظ', { fontFamily: 'Cairo', fontSize: 13, color: '#c9c1b4' }).setOrigin(0.5).setInteractive({ useHandCursor: true });
        continueBtn.on('pointerdown', () => this.startGame());
        this.add.text(w / 2, h - 55, 'رعب / ألغاز / استكشاف   •   العربية الفصحى   •   تجربة أصلية', { fontFamily: 'Cairo', fontSize: 11, color: '#68635c' }).setOrigin(0.5);
        this.tweens.add({ targets: title, alpha: 0.82, duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
        EventBus.emit('current-scene-ready', this);
        void shade;
    }

    private startGame(): void {
        if (this.started) return;
        this.started = true;
        this.cameras.main.fadeOut(800, 0, 0, 0);
        this.time.delayedCall(800, () => this.scene.start('Game'));
    }
}
