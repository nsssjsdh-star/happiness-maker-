import { Scene } from 'phaser';

export class Preloader extends Scene {
    constructor() { super('Preloader'); }
    preload(): void {
        this.load.image('room-foyer', 'assets/rooms/foyer.svg');
        this.load.image('room-library', 'assets/rooms/library.svg');
        this.load.image('room-office', 'assets/rooms/office.svg');
        this.load.image('room-basement', 'assets/rooms/basement.svg');
        this.load.image('player-art', 'assets/characters/player.svg');
        this.load.image('enemy-art', 'assets/characters/enemy.svg');
        this.load.image('noise', 'assets/ui/noise.svg');
        this.load.image('menu-bg', 'assets/menu/menu.svg');
    }
    create(): void { this.scene.start('MainMenu'); }
}
