import { Scene } from 'phaser';
import { EventBus } from '../EventBus';

type RoomId = 'foyer' | 'library' | 'office' | 'basement';
type ItemId = 'fuse' | 'brassKey' | 'lever' | 'battery' | 'note';
type EnemyState = 'patrol' | 'listen' | 'investigate' | 'chase' | 'search';

const W = 1280;
const H = 720;
const SAVE_KEY = 'almanzil-almansi-save-v6';

interface Point { x: number; y: number; }
interface Interactable { id: string; x: number; y: number; label: string; radius?: number; action: () => void; }

const ROOM_TITLES: Record<RoomId, string> = {
    foyer: 'الردهة الرئيسية',
    library: 'المكتبة القديمة',
    office: 'المكتب',
    basement: 'القبو'
};

const PATROLS: Record<RoomId, Point[]> = {
    foyer: [{ x: 1050, y: 230 }, { x: 1020, y: 500 }, { x: 770, y: 520 }, { x: 430, y: 250 }],
    library: [{ x: 220, y: 250 }, { x: 560, y: 520 }, { x: 1000, y: 260 }, { x: 780, y: 520 }],
    office: [{ x: 220, y: 250 }, { x: 1030, y: 260 }, { x: 1040, y: 540 }, { x: 500, y: 520 }],
    basement: [{ x: 180, y: 260 }, { x: 1080, y: 260 }, { x: 1040, y: 540 }, { x: 240, y: 540 }]
};

export class Game extends Scene {
    private player!: Phaser.GameObjects.Container;
    private playerArt!: Phaser.GameObjects.Image;
    private enemy!: Phaser.GameObjects.Container;
    private roomArt!: Phaser.GameObjects.Image;
    private darkness!: Phaser.GameObjects.Graphics;
    private fearBar!: Phaser.GameObjects.Graphics;
    private objectiveText!: Phaser.GameObjects.Text;
    private roomText!: Phaser.GameObjects.Text;
    private inventoryText!: Phaser.GameObjects.Text;
    private interactText!: Phaser.GameObjects.Text;
    private toastText!: Phaser.GameObjects.Text;
    private chapterText!: Phaser.GameObjects.Text;
    private pauseLayer?: Phaser.GameObjects.Container;
    private puzzleLayer?: Phaser.GameObjects.Container;
    private introLayer?: Phaser.GameObjects.Container;
    private hintTimer?: Phaser.Time.TimerEvent;

    private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
    private keys!: Record<string, Phaser.Input.Keyboard.Key>;
    private mobile = { up: false, down: false, left: false, right: false };
    private audio?: AudioContext;

    private room: RoomId = 'foyer';
    private previousRoom: RoomId = 'foyer';
    private playerPos: Point = { x: 620, y: 570 };
    private enemyPos: Point = { x: 1050, y: 230 };
    private enemyState: EnemyState = 'patrol';
    private enemyPatrolIndex = 0;
    private enemyTarget: Point = { x: 1050, y: 230 };
    private lastSeen: Point = { x: 620, y: 570 };
    private lastNoise = 0;
    private noisePower = 0;
    private fear = 8;
    private heartbeatClock = 0;

    private inventory = new Set<ItemId>();
    private powerOn = false;
    private librarySolved = false;
    private officeSolved = false;
    private safeSolved = false;
    private generatorOn = false;
    private basementOpen = false;
    private escaped = false;
    private hiding = false;
    private paused = false;
    private gameStarted = false;
    private playTime = 0;
    private objective = 'ابحث عن المصهر وأعد الكهرباء.';
    private interactables: Interactable[] = [];
    private optionalSolved = new Set<string>();
    private nearby?: Interactable;

    constructor() { super('Game'); }

    create(): void {
        this.cameras.main.setBackgroundColor('#050608');
        this.cameras.main.fadeIn(700, 0, 0, 0);
        this.setupInput();
        this.drawRoomArt();
        this.createPlayer();
        this.createEnemy();
        this.createHUD();
        this.createTouchControls();
        this.createAmbientParticles();
        this.loadSave();
        this.rebuildRoom();
        this.playIntro();
        EventBus.emit('current-scene-ready', this);
    }

    private setupInput(): void {
        const keyboard = this.input.keyboard;
        this.cursors = keyboard!.createCursorKeys();
        this.keys = keyboard!.addKeys('W,A,S,D,E,F,ESC,SHIFT') as Record<string, Phaser.Input.Keyboard.Key>;
        keyboard!.on('keydown-E', () => this.interact());
        keyboard!.on('keydown-F', () => this.toggleHide());
        keyboard!.on('keydown-ESC', () => this.togglePause());
        keyboard!.on('keydown-SHIFT', () => { this.noisePower = 1; });
    }

    private drawRoomArt(): void {
        this.roomArt = this.add.image(W / 2, H / 2, 'room-foyer').setDisplaySize(W, H).setDepth(-100);
        this.darkness = this.add.graphics().setDepth(390);
        this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.08).setDepth(380);
    }

    private createPlayer(): void {
        this.player = this.add.container(this.playerPos.x, this.playerPos.y).setDepth(250);
        const shadow = this.add.ellipse(0, 25, 44, 13, 0x000000, 0.65);
        this.playerArt = this.add.image(0, 0, 'player-art').setScale(0.75);
        const lamp = this.add.circle(0, -35, 5, 0xf5d88c, 0.95);
        this.player.add([shadow, this.playerArt, lamp]);
        this.tweens.add({ targets: this.playerArt, y: -3, duration: 430, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    }

    private createEnemy(): void {
        this.enemy = this.add.container(this.enemyPos.x, this.enemyPos.y).setDepth(240);
        const shadow = this.add.ellipse(0, 31, 58, 15, 0x000000, 0.75);
        const art = this.add.image(0, 0, 'enemy-art').setScale(0.78);
        this.enemy.add([shadow, art]);
        this.tweens.add({ targets: art, y: -5, duration: 520, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
    }

    private createHUD(): void {
        this.add.rectangle(W / 2, 39, W - 28, 62, 0x07090d, 0.78).setStrokeStyle(1, 0x3a3730, 0.9).setDepth(500);
        this.chapterText = this.add.text(42, 17, 'القضية 01  •  الفصل الأول', this.textStyle(11, '#a9956b', true)).setDepth(510);
        this.roomText = this.add.text(42, 43, ROOM_TITLES[this.room], this.textStyle(17, '#f0ebe2', true)).setDepth(510);
        this.add.text(330, 17, 'الهدف', this.textStyle(10, '#aa956a', true)).setDepth(510);
        this.objectiveText = this.add.text(330, 42, this.objective, this.textStyle(13, '#ddd7cc')).setDepth(510);
        this.inventoryText = this.add.text(1000, 18, 'الحقيبة: فارغة', this.textStyle(11, '#c6c0b6')).setDepth(510);
        this.add.text(1000, 45, 'الخوف', this.textStyle(10, '#8d8880')).setDepth(510);
        this.fearBar = this.add.graphics().setDepth(511);
        this.interactText = this.add.text(W / 2, H - 83, '', this.textStyle(14, '#f4eee3', true)).setOrigin(0.5).setDepth(510);
        this.toastText = this.add.text(W / 2, 108, '', this.textStyle(13, '#d8c59e', true)).setOrigin(0.5).setDepth(520).setAlpha(0);
    }

    private textStyle(size: number, color: string, bold = false): Phaser.Types.GameObjects.Text.TextStyle {
        return { fontFamily: 'Cairo, Arial, sans-serif', fontSize: size, color, fontStyle: bold ? '700' : '400', rtl: true };
    }

    private createTouchControls(): void {
        const base = this.add.circle(92, 625, 64, 0x080a0d, 0.6).setStrokeStyle(2, 0xd1bf95, 0.2).setDepth(600);
        base.setInteractive();
        const dirs: Array<[string, number, number, keyof typeof this.mobile]> = [
            ['↑', 92, 585, 'up'], ['←', 55, 625, 'left'], ['→', 129, 625, 'right'], ['↓', 92, 665, 'down']
        ];
        dirs.forEach(([label, x, y, key]) => {
            const b = this.add.text(x, y, label, { fontSize: 22, color: '#eee8dd' }).setOrigin(0.5).setDepth(601).setInteractive();
            b.on('pointerdown', () => { this.mobile[key] = true; });
            b.on('pointerup', () => { this.mobile[key] = false; });
            b.on('pointerout', () => { this.mobile[key] = false; });
        });
        const button = (x: number, y: number, label: string, callback: () => void) => {
            const b = this.add.text(x, y, label, this.textStyle(12, '#eee8dd', true)).setOrigin(0.5).setDepth(601).setPadding(14, 9, 14, 9).setBackgroundColor('#14171c').setInteractive();
            b.on('pointerdown', callback);
            b.on('pointerover', () => b.setAlpha(0.75));
            b.on('pointerout', () => b.setAlpha(1));
        };
        button(1165, 590, 'تفاعل', () => this.interact());
        button(1165, 655, 'اختباء', () => this.toggleHide());
        button(1085, 655, 'الحقيبة', () => this.showInventory());
    }

    private createAmbientParticles(): void {
        for (let i = 0; i < 45; i += 1) {
            const p = this.add.circle(Phaser.Math.Between(30, W - 30), Phaser.Math.Between(110, H - 30), Phaser.Math.Between(1, 3), 0xd8cbb5, Phaser.Math.FloatBetween(0.02, 0.08)).setDepth(150);
            this.tweens.add({ targets: p, y: p.y - Phaser.Math.Between(30, 120), alpha: 0, duration: Phaser.Math.Between(2500, 6500), repeat: -1, yoyo: true, delay: Phaser.Math.Between(0, 1800) });
        }
    }

    private playIntro(): void {
        if (this.gameStarted) return;
        this.gameStarted = true;
        const layer = this.add.container(0, 0).setDepth(1000);
        this.introLayer = layer;
        const black = this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.98);
        const time = this.add.text(W / 2, 255, '03:17', { fontFamily: 'monospace', fontSize: 74, color: '#ede7dc' }).setOrigin(0.5);
        const line1 = this.add.text(W / 2, 365, 'استيقظتَ على صوتٍ يأتي من الطابق السفلي.', this.textStyle(19, '#b9b2a7')).setOrigin(0.5).setAlpha(0);
        const line2 = this.add.text(W / 2, 410, 'ثم سمعتَ ثلاثةَ طرقات… من خلف الباب المقفل.', this.textStyle(16, '#7f7a72')).setOrigin(0.5).setAlpha(0);
        layer.add([black, time, line1, line2]);
        this.tweens.add({ targets: line1, alpha: 1, duration: 900, delay: 650 });
        this.tweens.add({ targets: line2, alpha: 1, duration: 900, delay: 1700 });
        this.time.delayedCall(3600, () => {
            this.tweens.add({ targets: layer, alpha: 0, duration: 800, onComplete: () => layer.destroy() });
            this.paused = false;
        });
    }

    private rebuildRoom(): void {
        this.roomArt.setTexture(`room-${this.room}`);
        this.roomText.setText(ROOM_TITLES[this.room]);
        this.interactables = [];
        this.nearby = undefined;
        this.configureRoomObjects();
        this.previousRoom = this.room;
        this.enemyState = 'patrol';
        this.enemyPatrolIndex = 0;
        this.enemyPos = PATROLS[this.room][0];
        this.enemy.setPosition(this.enemyPos.x, this.enemyPos.y);
        this.enemyTarget = this.enemyPos;
        this.player.setPosition(this.playerPos.x, this.playerPos.y);
        this.addRoomTransitionLabel();
        this.saveGame();
    }

    private configureRoomObjects(): void {
        if (this.room === 'foyer') {
            this.addInteraction('fusebox', 210, 300, 'لوحة الكهرباء', () => this.solveFuse());
            this.addInteraction('frontdoor', 640, 130, 'الباب الرئيسي', () => this.tryFrontDoor());
            this.addInteraction('library', 445, 150, 'دخول المكتبة', () => this.enterRoom('library', 620, 610));
            this.addInteraction('office', 835, 150, 'دخول المكتب', () => this.enterRoom('office', 620, 610));
            this.addInteraction('basement', 640, 650, this.basementOpen ? 'نزول إلى القبو' : 'باب القبو مغلق', () => {
                if (this.basementOpen) this.enterRoom('basement', 620, 150); else this.toast('الباب لا يتحرك. ربما يحتاج إلى طاقة.');
            });
            if (!this.inventory.has('fuse')) this.addInteraction('fuse', 330, 500, 'التقاط المصهر', () => this.pick('fuse', 'وجدتَ مصهرًا احتياطيًا.'));
            this.optionalPuzzle('portrait', 1080, 300, 'فحص اللوحة', 'رتّب أرقام الإطار كما تشير الأسهم.', ['2','4','1'], '241', 'وراء اللوحة فراغ صغير.');
            this.optionalPuzzle('clock', 760, 360, 'ضبط الساعة', 'اجعل العقارب تشير إلى 03:17.', ['03','17'], '0317', 'سمعتَ صوت نابض من الحائط.');
            this.optionalPuzzle('umbrella', 1050, 560, 'فحص صندوق المظلات', 'اختر القطعة التي لا تنتمي إلى المجموعة.', ['A','B','C'], 'B', 'وجدتَ قصاصة مكتوبًا عليها: لا تثق بالمرآة.');
        }
        if (this.room === 'library') {
            this.addInteraction('books', 255, 245, 'فحص الرفوف', () => this.solveLibrary());
            this.addInteraction('return', 1110, 600, 'العودة إلى الردهة', () => this.enterRoom('foyer', 500, 180));
            if (!this.inventory.has('note')) this.addInteraction('note', 860, 430, 'قراءة المذكرة', () => this.pick('note', 'المذكرة تحمل رمزًا: 4 — 1 — 7 — 9.'));
            this.optionalPuzzle('candle', 610, 160, 'شموع المكتبة', 'أشعل الشموع من الأقصر إلى الأطول.', ['1','2','3'], '123', 'انفتح تجويف خلف رف الكتب.');
            this.optionalPuzzle('chess', 1000, 500, 'رقعة الشطرنج', 'حرّك القطعة إلى المربع الذي لا يمكن الوصول إليه بحركة الحصان.', ['A','B','C','D'], 'D', 'وجدتَ رمزًا: 8.');
            this.optionalPuzzle('ledger', 420, 500, 'دفتر الحسابات', 'أكمل السلسلة: 2، 4، 8، ؟', ['12','14','16'], '16', 'الهامش يحمل كلمة: المولد.');
        }
        if (this.room === 'office') {
            this.addInteraction('desk', 560, 250, 'فحص المكتب', () => this.solveOffice());
            this.addInteraction('safe', 1020, 250, 'فتح الخزنة', () => this.openSafe());
            this.addInteraction('return', 170, 600, 'العودة إلى الردهة', () => this.enterRoom('foyer', 800, 180));
            if (!this.inventory.has('battery')) this.addInteraction('battery', 360, 470, 'التقاط البطارية', () => this.pick('battery', 'بطارية قديمة، لكنها لا تزال تعمل.'));
            this.optionalPuzzle('typewriter', 580, 420, 'آلة الكتابة', 'اكتب الحرف الذي يتكرر في كل كلمة من المذكرة.', ['A','R','M','S'], 'R', 'ظهرت إشارة إلى القبو.');
            this.optionalPuzzle('radio', 890, 520, 'الراديو القديم', 'اضبط المحطات بالترتيب الصحيح: 2 ثم 7 ثم 4.', ['2','7','4'], '274', 'سمعتَ رسالة مشوشة: لا تنظر خلفك.');
            this.optionalPuzzle('mirror', 1080, 410, 'المرآة', 'اختر الانعكاس الصحيح للرمز.', ['↗','↘','↙'], '↙', 'وجدتَ علامة مخفية على الجدار.');
        }
        if (this.room === 'basement') {
            this.addInteraction('generator', 640, 510, 'تشغيل المولد', () => this.solveGenerator());
            this.addInteraction('lever', 980, 500, 'استخدام العتلة', () => this.solveLever());
            this.addInteraction('return', 640, 145, 'الصعود إلى الردهة', () => this.enterRoom('foyer', 640, 600));
            this.optionalPuzzle('pipes', 300, 300, 'صمامات الأنابيب', 'اجعل الضغط يرتفع من اليسار إلى اليمين.', ['L','M','R'], 'LMR', 'بدأت الأنابيب بالاهتزاز.');
            this.optionalPuzzle('breaker', 1040, 250, 'القاطع الرئيسي', 'اختر القاطع الذي لا يحمل أثر احتراق.', ['1','2','3','4'], '3', 'مصباح أحمر بعيد أضاء للحظة.');
            this.optionalPuzzle('floor', 520, 620, 'بلاطات القبو', 'اخطُ على البلاطات: 1، 3، 2، 4.', ['1','3','2','4'], '1324', 'سمعتَ قفلاً يفتح في مكان مجهول.');
        }
    }

    private addInteraction(id: string, x: number, y: number, label: string, action: () => void): void {
        this.interactables.push({ id, x, y, label, action, radius: 70 });
    }

    private optionalPuzzle(id: string, x: number, y: number, label: string, subtitle: string, keys: string[], answer: string, success: string): void {
        if (this.optionalSolved.has(id)) return;
        this.addInteraction(id, x, y, label, () => this.showPuzzle(label, subtitle, keys, (entered) => {
            if (entered === answer) {
                this.optionalSolved.add(id);
                this.closePuzzle();
                this.toast(success);
                this.playTone(640, 0.12, 'triangle');
                this.saveGame();
            } else this.toast('ليس هذا هو الترتيب الصحيح.');
        }, false));
    }

    private addRoomTransitionLabel(): void {
        const label = this.add.text(W / 2, 120, ROOM_TITLES[this.room], this.textStyle(14, '#b9ad96', true)).setOrigin(0.5).setDepth(470).setAlpha(0);
        this.tweens.add({ targets: label, alpha: 1, duration: 350, hold: 1000, yoyo: true, onComplete: () => label.destroy() });
    }

    private pick(item: ItemId, message: string): void {
        this.inventory.add(item);
        this.toast(message);
        this.playTone(520, 0.08, 'triangle');
        this.rebuildRoom();
        this.updateObjective();
    }

    private solveFuse(): void {
        if (this.powerOn) { this.toast('الكهرباء تعمل بالفعل.'); return; }
        if (!this.inventory.has('fuse')) { this.toast('اللوحة تحتاج إلى مصهر. ابحث في الردهة.'); return; }
        this.showPuzzle('لوحة الكهرباء', 'رتّب الدوائر حتى تضيء المؤشرات الثلاثة.', ['1','2','3','4'], (answer) => {
            if (answer === '3142') {
                this.powerOn = true;
                this.basementOpen = true;
                this.objective = 'فتّش المكتب عن رمز الخزنة.';
                this.closePuzzle();
                this.toast('عادت الكهرباء… لكن صوتًا آخر استيقظ معها.');
                this.playTone(180, 0.45, 'sawtooth');
                this.rebuildRoom();
            } else this.toast('الترتيب خاطئ. هناك نمط مخفي في اللوحة.');
        }, true);
    }

    private solveLibrary(): void {
        if (this.librarySolved) { this.toast('لا شيء آخر هنا.'); return; }
        this.showPuzzle('لغز الرفوف', 'اختر تسلسل الكتب وفق أرقام المذكرة: 4 — 1 — 7 — 9.', ['4','1','7','9'], (answer) => {
            if (answer === '4179') {
                this.librarySolved = true;
                this.objective = 'ادخل المكتب وابحث عن الخزنة.';
                this.closePuzzle();
                this.toast('انفتح درج سري تحت الرف.');
                this.addInteraction('key', 600, 520, 'التقاط المفتاح النحاسي', () => this.pick('brassKey', 'مفتاح نحاسي بارد بصورة غير طبيعية.'));
            } else this.toast('التسلسل لا يطابق المذكرة.');
        }, false);
    }

    private solveOffice(): void {
        if (this.officeSolved) { this.toast('وجدتَ كل ما يمكن هنا.'); return; }
        if (!this.librarySolved) { this.toast('المكتب يخفي لغزًا. ربما المكتبة تحتوي على الدليل.'); return; }
        this.showPuzzle('ساعة المكتب', 'أوقف العقارب عند الوقت الذي بدأت فيه الحكاية.', ['03','17'], (answer) => {
            if (answer === '0317') {
                this.officeSolved = true;
                this.objective = 'افتح الخزنة بالرمز الذي وجدته.';
                this.closePuzzle();
                this.toast('توقفت الساعة. سُمِعَت طَقّة من جهة الخزنة.');
            } else this.toast('العقارب لا تتطابق مع الدليل.');
        }, true);
    }

    private openSafe(): void {
        if (this.safeSolved) { this.toast('الخزنة فارغة.'); return; }
        if (!this.officeSolved) { this.toast('الخزنة لا تستجيب. ابحث عن الدليل أولًا.'); return; }
        this.showPuzzle('الخزنة', 'أدخل الرمز المكوّن من أربعة أرقام.', ['4','1','7','9'], (answer) => {
            if (answer === '4179') {
                this.safeSolved = true;
                this.inventory.add('lever');
                this.inventory.add('brassKey');
                this.objective = 'انزل إلى القبو وشغّل المولد.';
                this.closePuzzle();
                this.toast('وجدتَ عتلة ومفتاحًا. لكن هناك آثارًا حديثة على الأرض.');
                this.updateObjective();
            } else this.toast('الرمز خاطئ.');
        }, true);
    }

    private solveGenerator(): void {
        if (this.generatorOn) { this.toast('المولد يعمل.'); return; }
        if (!this.inventory.has('battery')) { this.toast('المولد يحتاج إلى بطارية.'); return; }
        this.showPuzzle('المولد', 'وصّل الطاقة بالتسلسل الصحيح: بطارية ← مفتاح ← محرك.', ['B','S','M'], (answer) => {
            if (answer === 'BSM') {
                this.generatorOn = true;
                this.objective = 'استخدم العتلة لفتح باب الخدمة.';
                this.closePuzzle();
                this.playTone(80, 0.6, 'square');
                this.toast('المولد اشتغل. باب الخدمة اهتز من تلقاء نفسه.');
            } else this.toast('التوصيل خاطئ.');
        }, false);
    }

    private solveLever(): void {
        if (!this.generatorOn) { this.toast('الباب لن يتحرك دون تشغيل المولد.'); return; }
        if (!this.inventory.has('lever')) { this.toast('تحتاج إلى عتلة.'); return; }
        this.objective = 'افتح الباب الرئيسي واخرج من المنزل.';
        this.toast('انفتح ممر الخدمة. أصبحت طريق العودة إلى الخارج ممكنة.');
        this.powerOn = true;
        this.basementOpen = true;
        this.enterRoom('foyer', 640, 590);
    }

    private tryFrontDoor(): void {
        if (!this.generatorOn) { this.toast('الباب الرئيسي مقفل. هناك قفل كهربائي.'); return; }
        if (!this.inventory.has('brassKey')) { this.toast('ينقصك مفتاح نحاسي.'); return; }
        this.win();
    }

    private enterRoom(next: RoomId, x: number, y: number): void {
        if (this.room === next) return;
        this.previousRoom = this.room;
        this.room = next;
        this.playerPos = { x, y };
        this.cameras.main.fadeOut(300, 0, 0, 0);
        this.time.delayedCall(300, () => {
            this.cameras.main.fadeIn(400, 0, 0, 0);
            this.rebuildRoom();
            this.makeNoise(0.3);
        });
    }

    private showPuzzle(title: string, subtitle: string, keys: string[], callback: (answer: string) => void, numeric: boolean): void {
        this.closePuzzle();
        this.paused = true;
        const layer = this.add.container(0, 0).setDepth(900);
        this.puzzleLayer = layer;
        const shade = this.add.rectangle(W / 2, H / 2, W, H, 0x020304, 0.88);
        const card = this.add.rectangle(W / 2, H / 2, 610, 360, 0x0b0e12, 0.98).setStrokeStyle(1, 0x776646, 0.9);
        const t = this.add.text(W / 2, 205, title, this.textStyle(27, '#eee7dc', true)).setOrigin(0.5);
        const s = this.add.text(W / 2, 252, subtitle, this.textStyle(13, '#aaa39a')).setOrigin(0.5);
        const display = this.add.text(W / 2, 315, '', { fontFamily: 'monospace', fontSize: 34, color: '#cdb47d' }).setOrigin(0.5);
        const sequence: string[] = [];
        const positions = [390, 485, 580, 675];
        keys.forEach((k, i) => {
            const b = this.add.text(positions[i] ?? 625, 405, k, { fontFamily: 'monospace', fontSize: 22, color: '#eee8dd', backgroundColor: '#1b1f25', padding: { left: 22, right: 22, top: 14, bottom: 14 } }).setOrigin(0.5).setInteractive();
            b.on('pointerdown', () => {
                sequence.push(k);
                display.setText(sequence.join(''));
                this.playTone(380 + i * 60, 0.04, 'sine');
                if (sequence.length === keys.length) callback(sequence.join(''));
            });
            layer.add(b);
        });
        const close = this.add.text(W / 2, 475, 'إغلاق  •  ESC', this.textStyle(12, '#8f8a82')).setOrigin(0.5).setInteractive();
        close.on('pointerdown', () => this.closePuzzle());
        layer.add([shade, card, t, s, display, close]);
        layer.moveTo(shade, 0);
    }

    private closePuzzle(): void {
        if (this.puzzleLayer) { this.puzzleLayer.destroy(); this.puzzleLayer = undefined; }
        this.paused = false;
    }

    private interact(): void {
        if (this.paused || this.hiding) return;
        if (this.nearby) this.nearby.action();
        else this.toast('لا يوجد شيء قريب يمكن التفاعل معه.');
    }

    private toggleHide(): void {
        if (this.paused) return;
        this.hiding = !this.hiding;
        this.player.setAlpha(this.hiding ? 0.18 : 1);
        this.toast(this.hiding ? 'اختبأتَ. لا تتحرك.' : 'خرجتَ من مخبئك.');
        this.makeNoise(this.hiding ? 0.05 : 0.5);
    }

    private showInventory(): void {
        const names: Record<ItemId, string> = { fuse: 'مصهر', brassKey: 'مفتاح نحاسي', lever: 'عتلة', battery: 'بطارية', note: 'مذكرة' };
        const list = [...this.inventory].map((x) => names[x]).join('  •  ') || 'فارغة';
        this.toast(`الحقيبة: ${list}`);
    }

    togglePause(): void {
        if (this.puzzleLayer || this.escaped) return;
        this.paused = !this.paused;
        EventBus.emit('pause-ui', this.paused);
        if (this.paused) this.showPause(); else this.hidePause();
    }

    private showPause(): void {
        if (this.pauseLayer) return;
        const layer = this.add.container(0, 0).setDepth(950);
        this.pauseLayer = layer;
        const bg = this.add.rectangle(W / 2, H / 2, W, H, 0x020304, 0.8);
        const card = this.add.rectangle(W / 2, H / 2, 390, 230, 0x0b0d11, 1).setStrokeStyle(1, 0x6e6048, 0.9);
        const title = this.add.text(W / 2, 285, 'متوقف مؤقتًا', this.textStyle(26, '#eee8dc', true)).setOrigin(0.5);
        const resume = this.add.text(W / 2, 360, 'متابعة', this.textStyle(16, '#15120d', true)).setOrigin(0.5).setPadding(28, 12, 28, 12).setBackgroundColor('#c5ab76').setInteractive();
        resume.on('pointerdown', () => this.togglePause());
        const save = this.add.text(W / 2, 425, 'حفظ التقدم', this.textStyle(12, '#b9b2a7')).setOrigin(0.5).setInteractive();
        save.on('pointerdown', () => { this.saveGame(); this.toast('تم حفظ التقدم.'); });
        layer.add([bg, card, title, resume, save]);
    }

    private hidePause(): void { this.pauseLayer?.destroy(); this.pauseLayer = undefined; }

    private updatePlayer(delta: number): void {
        const left = this.cursors.left.isDown || this.keys.A.isDown || this.mobile.left;
        const right = this.cursors.right.isDown || this.keys.D.isDown || this.mobile.right;
        const up = this.cursors.up.isDown || this.keys.W.isDown || this.mobile.up;
        const down = this.cursors.down.isDown || this.keys.S.isDown || this.mobile.down;
        const speed = (this.keys.SHIFT.isDown ? 190 : 145) * (this.hiding ? 0.28 : 1);
        let dx = (right ? 1 : 0) - (left ? 1 : 0);
        let dy = (down ? 1 : 0) - (up ? 1 : 0);
        if (dx !== 0 || dy !== 0) {
            const len = Math.hypot(dx, dy) || 1;
            dx /= len; dy /= len;
            this.playerPos.x = Phaser.Math.Clamp(this.playerPos.x + dx * speed * delta / 1000, 75, W - 75);
            this.playerPos.y = Phaser.Math.Clamp(this.playerPos.y + dy * speed * delta / 1000, 135, H - 55);
            this.player.setPosition(this.playerPos.x, this.playerPos.y);
            this.playerArt.setFlipX(dx < 0);
            this.makeNoise(this.keys.SHIFT.isDown ? 0.75 : 0.22);
        }
    }

    private makeNoise(power: number): void {
        this.lastNoise = this.time.now;
        this.noisePower = Math.max(this.noisePower, power);
    }

    private updateEnemy(delta: number): void {
        if (this.room !== this.previousRoom && this.enemyState !== 'patrol') this.enemyState = 'patrol';
        const distance = Phaser.Math.Distance.Between(this.playerPos.x, this.playerPos.y, this.enemyPos.x, this.enemyPos.y);
        const seesPlayer = !this.hiding && distance < 330 && this.hasLineOfSight();
        if (seesPlayer) {
            this.enemyState = 'chase';
            this.lastSeen = { ...this.playerPos };
            this.enemyTarget = this.lastSeen;
        } else if (this.noisePower > 0.15 && this.time.now - this.lastNoise < 900) {
            this.enemyState = 'investigate';
            this.enemyTarget = { ...this.playerPos };
        } else if (this.enemyState === 'chase' && distance > 460) {
            this.enemyState = 'search';
            this.enemyTarget = this.lastSeen;
        }
        if (this.enemyState === 'patrol') {
            const target = PATROLS[this.room][this.enemyPatrolIndex];
            this.enemyTarget = target;
            if (Phaser.Math.Distance.Between(this.enemyPos.x, this.enemyPos.y, target.x, target.y) < 18) this.enemyPatrolIndex = (this.enemyPatrolIndex + 1) % PATROLS[this.room].length;
        }
        const speed = this.enemyState === 'chase' ? 126 : this.enemyState === 'investigate' ? 98 : 62;
        this.moveEnemyToward(this.enemyTarget, speed, delta);
        if (distance < 48 && !this.hiding) this.lose();
        this.fear = Phaser.Math.Clamp(this.fear + (distance < 230 ? 11 : distance < 400 ? 3 : -5) * delta / 1000, 0, 100);
        this.noisePower *= 0.94;
        this.enemy.setPosition(this.enemyPos.x, this.enemyPos.y);
        const art = this.enemy.list[1] as Phaser.GameObjects.Image;
        art.setTint(this.enemyState === 'chase' ? 0xffd0d0 : 0xffffff);
    }

    private moveEnemyToward(target: Point, speed: number, delta: number): void {
        const dx = target.x - this.enemyPos.x;
        const dy = target.y - this.enemyPos.y;
        const d = Math.hypot(dx, dy) || 1;
        this.enemyPos.x += dx / d * speed * delta / 1000;
        this.enemyPos.y += dy / d * speed * delta / 1000;
        this.enemyPos.x = Phaser.Math.Clamp(this.enemyPos.x, 75, W - 75);
        this.enemyPos.y = Phaser.Math.Clamp(this.enemyPos.y, 135, H - 55);
    }

    private hasLineOfSight(): boolean {
        // Lightweight stealth model: room geometry is visually rich, while collision/LOS stays deterministic.
        const dx = this.playerPos.x - this.enemyPos.x;
        const dy = this.playerPos.y - this.enemyPos.y;
        return Math.abs(dx) + Math.abs(dy) < 560;
    }

    private updateNearby(): void {
        let best: Interactable | undefined;
        let bestDistance = Infinity;
        for (const item of this.interactables) {
            const d = Phaser.Math.Distance.Between(this.playerPos.x, this.playerPos.y, item.x, item.y);
            if (d < (item.radius ?? 70) && d < bestDistance) { best = item; bestDistance = d; }
        }
        this.nearby = best;
        this.interactText.setText(best ? `◉  ${best.label}  •  E / تفاعل` : '');
    }

    private updateLighting(): void {
        this.darkness.clear();
        const alpha = 0.58 + this.fear * 0.0015;
        this.darkness.fillStyle(0x000000, alpha);
        this.darkness.fillRect(0, 0, W, H);
        this.darkness.setBlendMode(Phaser.BlendModes.ERASE);
        this.darkness.fillStyle(0xffffff, 0.96);
        this.darkness.fillCircle(this.playerPos.x, this.playerPos.y - 8, 155);
        this.darkness.fillStyle(0xffffff, 1);
        this.darkness.fillCircle(this.playerPos.x, this.playerPos.y - 8, 82);
        this.darkness.setBlendMode(Phaser.BlendModes.NORMAL);
        if (this.fear > 62) {
            this.darkness.fillStyle(0x24080b, (this.fear - 62) * 0.0025);
            this.darkness.fillRect(0, 0, W, H);
        }
    }

    private updateHUD(): void {
        this.objectiveText.setText(this.objective);
        const names: Record<ItemId, string> = { fuse: 'مصهر', brassKey: 'مفتاح', lever: 'عتلة', battery: 'بطارية', note: 'مذكرة' };
        this.inventoryText.setText(`الحقيبة: ${[...this.inventory].map((i) => names[i]).join(' • ') || 'فارغة'}`);
        this.fearBar.clear();
        this.fearBar.fillStyle(0x17191d, 1); this.fearBar.fillRoundedRect(1070, 43, 155, 8, 4);
        this.fearBar.fillStyle(this.fear > 65 ? 0x9b4545 : 0xbda56f, 1); this.fearBar.fillRoundedRect(1070, 43, 155 * this.fear / 100, 8, 4);
        if (this.fear > 72) this.cameras.main.shake(40, 0.001 + this.fear * 0.00001);
    }

    private updateHeartbeat(delta: number): void {
        if (this.fear < 45) return;
        this.heartbeatClock -= delta;
        if (this.heartbeatClock <= 0) {
            this.heartbeatClock = Math.max(330, 850 - this.fear * 4);
            this.playTone(58, 0.045, 'sine');
            if (this.fear > 82) this.playTone(48, 0.035, 'sine');
        }
    }

    private toast(message: string): void {
        this.toastText.setText(message).setAlpha(1);
        if (this.hintTimer) this.hintTimer.remove(false);
        this.hintTimer = this.time.delayedCall(2400, () => this.tweens.add({ targets: this.toastText, alpha: 0, duration: 450 }));
    }

    private playTone(frequency: number, duration: number, type: OscillatorType): void {
        try {
            this.audio ??= new AudioContext();
            const osc = this.audio.createOscillator();
            const gain = this.audio.createGain();
            osc.type = type; osc.frequency.value = frequency;
            gain.gain.setValueAtTime(0.0001, this.audio.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.045, this.audio.currentTime + 0.01);
            gain.gain.exponentialRampToValueAtTime(0.0001, this.audio.currentTime + duration);
            osc.connect(gain); gain.connect(this.audio.destination); osc.start(); osc.stop(this.audio.currentTime + duration + 0.02);
        } catch { /* Browser audio may require a gesture. */ }
    }

    private saveGame(): void {
        try {
            localStorage.setItem(SAVE_KEY, JSON.stringify({ room: this.room, playerPos: this.playerPos, inventory: [...this.inventory], powerOn: this.powerOn, librarySolved: this.librarySolved, officeSolved: this.officeSolved, safeSolved: this.safeSolved, generatorOn: this.generatorOn, basementOpen: this.basementOpen, objective: this.objective, optionalSolved: [...this.optionalSolved], playTime: this.playTime }));
        } catch { /* storage is optional */ }
    }

    private loadSave(): void {
        try {
            const raw = localStorage.getItem(SAVE_KEY);
            if (!raw) return;
            const data = JSON.parse(raw) as Partial<{ room: RoomId; playerPos: Point; inventory: ItemId[]; powerOn: boolean; librarySolved: boolean; officeSolved: boolean; safeSolved: boolean; generatorOn: boolean; basementOpen: boolean; objective: string; optionalSolved: string[]; playTime: number }>;
            if (data.room) this.room = data.room;
            if (data.playerPos) this.playerPos = data.playerPos;
            if (data.inventory) this.inventory = new Set(data.inventory);
            this.powerOn = Boolean(data.powerOn); this.librarySolved = Boolean(data.librarySolved); this.officeSolved = Boolean(data.officeSolved); this.safeSolved = Boolean(data.safeSolved); this.generatorOn = Boolean(data.generatorOn); this.basementOpen = Boolean(data.basementOpen);
            if (data.objective) this.objective = data.objective;
            if (data.optionalSolved) this.optionalSolved = new Set(data.optionalSolved);
            this.playTime = data.playTime ?? 0;
        } catch { /* corrupt save is ignored */ }
    }

    private updateObjective(): void {
        this.saveGame();
        EventBus.emit('objective', this.objective);
    }

    private lose(): void {
        if (this.escaped || this.paused) return;
        this.escaped = true;
        this.paused = true;
        this.cameras.main.shake(500, 0.015);
        this.cameras.main.fadeOut(600, 0, 0, 0);
        this.time.delayedCall(750, () => this.scene.start('GameOver', { reason: 'caught' }));
    }

    private win(): void {
        if (this.escaped) return;
        this.escaped = true; this.paused = true;
        this.cameras.main.flash(700, 215, 195, 150);
        const layer = this.add.container(0, 0).setDepth(1000);
        layer.add(this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.84));
        layer.add(this.add.text(W / 2, 270, 'خرجتَ من المنزل…', this.textStyle(34, '#eee8dc', true)).setOrigin(0.5));
        layer.add(this.add.text(W / 2, 335, 'لكن الطرقات لم تتوقف.', this.textStyle(18, '#b7aea1')).setOrigin(0.5));
        layer.add(this.add.text(W / 2, 395, 'الفصل الأول انتهى.', this.textStyle(13, '#9f875e')).setOrigin(0.5));
        this.saveGame();
        this.time.delayedCall(3000, () => this.scene.start('GameOver', { reason: 'escaped' }));
    }

    update(_time: number, delta: number): void {
        if (this.introLayer || this.escaped) return;
        if (this.paused) return;
        this.playTime += delta / 1000;
        this.updatePlayer(delta);
        this.updateEnemy(delta);
        this.updateNearby();
        this.updateLighting();
        this.updateHUD();
        this.updateHeartbeat(delta);
        if (Math.floor(this.playTime) % 8 === 0) this.saveGame();
    }
}
