import { AUTO, Game } from 'phaser';
import { Boot } from './scenes/Boot';
import { Preloader } from './scenes/Preloader';
import { MainMenu } from './scenes/MainMenu';
import { Game as MainGame } from './scenes/Game';
import { GameOver } from './scenes/GameOver';
const config: Phaser.Types.Core.GameConfig={type:AUTO,width:1280,height:720,parent:'game-container',backgroundColor:'#050608',scene:[Boot,Preloader,MainMenu,MainGame,GameOver],scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},render:{antialias:true,pixelArt:false,roundPixels:false}};
export default function StartGame(parent:string){return new Game({...config,parent})}
