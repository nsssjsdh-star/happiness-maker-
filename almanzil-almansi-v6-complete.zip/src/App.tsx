import { useEffect, useRef, useState } from 'react';
import { PhaserGame, IRefPhaserGame } from './PhaserGame';
import { EventBus } from './game/EventBus';
import './app.css';

export default function App() {
    const phaserRef = useRef<IRefPhaserGame | null>(null);
    const [showPause, setShowPause] = useState(false);
    const [objective, setObjective] = useState('ابحث عن المصهر وأعد الكهرباء.');

    useEffect(() => {
        const onObjective = (text: string) => setObjective(text);
        const onPause = (paused: boolean) => setShowPause(paused);
        EventBus.on('objective', onObjective);
        EventBus.on('pause-ui', onPause);
        return () => { EventBus.removeListener('objective', onObjective); EventBus.removeListener('pause-ui', onPause); };
    }, []);

    const togglePause = () => (phaserRef.current?.scene as { togglePause?: () => void } | null)?.togglePause?.();
    void objective;

    return <main className="app-shell"><div className="game-frame"><PhaserGame ref={phaserRef}/><div className="hud-top"><span>{objective}</span><button onClick={togglePause}>Ⅱ</button></div><div className="vignette"/>{showPause && <div className="pause-card"><b>متوقف مؤقتًا</b><small>اضغط ESC أو زر المتابعة داخل اللعبة</small></div>}</div></main>;
}
