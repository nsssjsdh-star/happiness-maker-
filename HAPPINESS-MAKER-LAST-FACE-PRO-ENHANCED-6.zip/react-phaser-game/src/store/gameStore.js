import { create } from 'zustand'
import { houses as initialHouses } from '../data/houses'

// Helper to find a random normal villager house
const findRandomNormalHouse = (houses) => {
  const normalHouses = houses.filter(h => h.type === 'villager' && h.status === 'normal')
  if (normalHouses.length === 0) return null
  const randomIndex = Math.floor(Math.random() * normalHouses.length)
  return normalHouses[randomIndex]
}

import { gameApi } from '../services/api'

export const useGameStore = create((set, get) => {
  return {
    houses: JSON.parse(JSON.stringify(initialHouses)),
    cycle: 1,
    isPaused: false,
    currentHouse: null,
    sessionId: null,
    evidence: [],
    inspected: {},
    discoveryToast: null,
    caseBoardOpen: false,
    inspectionOpen: false,
    inspectedSpots: {},

    // Actions

    // Initialize Game Session (call on App mount)
    initSession: async () => {
      // Always create a new session (Reset)
      const data = await gameApi.createSession()
      if (data && data.session_id) {
        set({ sessionId: data.session_id })
        console.log("Game Session Started:", data.session_id)
      }
    },

    // Open house interaction

    // Open house interaction
    openHouseEvent: (houseId) => {
      const { houses, cycle, evidence, inspected } = get()
      const house = houses.find(h => h.id === houseId)
      if (!house) return
      const key = `${cycle}:${houseId}`
      const discoveries = {
        house_corin: 'أثر أقدام ينتهي فجأة أمام باب منزل كريم.',
        house_1: 'إسماعيل يتذكر تفاصيل دقيقة عن ليلة الاختفاء، لكنه يتجنب ذكر مصدر معرفته.',
        house_2: 'أمينة تكرر أن الخوف اختفى من بعض الوجوه بعد الليلة الأولى.',
        house_3: 'في منزل ياسين، وُجدت ساعة متوقفة عند وقت الوفاة المزعوم.',
        house_4: 'مريم كانت تعمل على ثوب يحمل نقشاً لا تعرف تفسيره بعد تغيّرها.',
        house_5: 'الحاج عمر لاحظ أن أحد السكان لم يعد يتصرف بالطريقة نفسها التي اعتادها.'
      }
      const clueText = discoveries[houseId]
      const already = !!inspected[key]
      const nextEvidence = clueText && !already ? [{id:key, day:cycle, title:'ملاحظة جديدة', text:clueText}, ...evidence].slice(0,12) : evidence
      set({ currentHouse: house, isPaused: true, inspected: {...inspected, [key]: true}, evidence: nextEvidence, discoveryToast: !already && clueText ? clueText : null })
      if (!already && clueText) window.setTimeout(() => set({discoveryToast:null}), 2600)
    },

    clearDiscoveryToast: () => set({discoveryToast:null}),
    openInspection: () => set({inspectionOpen:true}),
    closeInspection: () => set({inspectionOpen:false}),
    inspectSpot: (houseId, spot) => {
      const { cycle, inspectedSpots, evidence } = get()
      const key = `${cycle}:${houseId}:${spot.id}`
      if (inspectedSpots[key]) return
      const item = { id:`spot-${key}`, day:cycle, title:spot.title, text:spot.text }
      set({ inspectedSpots:{...inspectedSpots, [key]:true}, evidence:[item, ...evidence].slice(0,12), discoveryToast:`تم العثور على دليل: ${spot.title}` })
      window.setTimeout(() => set({discoveryToast:null}), 2600)
    },
    setCaseBoardOpen: (open) => set({caseBoardOpen: open}),

    // Close interaction
    closeHouseMenu: () => {
      set({
        currentHouse: null,
        inspectionOpen: false,
        isPaused: false
      })
    },

    // Sleep action (triggered from Guard House - Moves to Day 2)
    sleep: async () => {
      const { houses, cycle, sessionId } = get()
      const nextCycle = cycle + 1

      // Sync with backend
      if (sessionId) {
        gameApi.advanceDay(sessionId)
      }

      let newHouses = houses.map(h => {
        const house = { ...h }
        const dayKey = `day${nextCycle}`

        if (house[dayKey]) {
          if (house[dayKey].npc) {
            house.npc = house[dayKey].npc
          }
          if (house[dayKey].status) {
            house.status = house[dayKey].status
          }
          if (house[dayKey].infectedImage) {
            house.infectedImage = house[dayKey].infectedImage
          }
        }
        return house
      })

      // الليلة الرابعة: الحاج عمر هو آخر ضحية، ليبقى إسماعيل وأمينة للمواجهة النهائية.
      if (nextCycle === 4) {
        const elder = newHouses.find(h => h.id === 'house_5')
        if (elder) {
          elder.status = 'dead'
          elder.infectedImage = 'assets/murder-house2.png'
        }
      }

      set({
        houses: newHouses,
        cycle: nextCycle,
        currentHouse: null,
        inspectionOpen: false,
        isPaused: false
      })
    },

    // --- ELIMINATION LOGIC ---
    skinwalkerId: null, // Deprecated, handled by backend
    hasWon: false,
    hasLost: false, // New explicit loss state
    eliminationMode: false,
    endGameMessage: "", // Store the result message

    setEliminationMode: (isActive) => set({ eliminationMode: isActive }),

    eliminateVillager: async (targetId) => {
      const { houses, sessionId } = get()
      const targetHouse = houses.find(h => h.id === targetId)

      if (!targetHouse || !targetHouse.npc) {
        console.error("Target invalid")
        return
      }

      const characterName = targetHouse.npc.name
      console.log("Eliminating:", characterName)

      // Call Backend
      if (sessionId) {
        const result = await gameApi.eliminate(sessionId, characterName, get().cycle)

        if (result && result.result === 'win') {
          set({
            hasWon: true,
            eliminationMode: false,
            isPaused: true,
            endGameMessage: result.message
          })
        } else {
          // LOSE or ERROR (Treat error as loss for high stakes? Or just alert?)
          // User said "if you are wrong you lose"
          set({
            hasLost: true,
            eliminationMode: false,
            isPaused: true,
            endGameMessage: result.message || "اتهمتي شخص بريء... والمخلوق ما زال حر."
          })
        }
      } else {
        const target = {1:"ياسين — الصيّاد",2:"مريم — الخيّاطة",3:"الحاج عمر",4:"إسماعيل — الطحّان"}[get().cycle]
        if (characterName === target) set({hasWon:true,eliminationMode:false,isPaused:true,endGameMessage:"أصبت الحقيقة. جمعت الأدلة الصحيحة وكشفت من كان يختبئ خلف الوجوه."})
        else set({hasLost:true,eliminationMode:false,isPaused:true,endGameMessage:"كان الاتهام خاطئاً. انتهى التحقيق قبل أن تصل إلى الحقيقة."})
      }
    },

    // --- JOURNAL LOGIC ---
    journalEntries: [],

    addJournalEntry: (text) => {
      const { journalEntries, cycle } = get()
      const newEntry = {
        id: Date.now(),
        day: cycle,
        text,
        time: new Date().toLocaleTimeString()
      }
      set({ journalEntries: [newEntry, ...journalEntries] })
    }

  }
})
