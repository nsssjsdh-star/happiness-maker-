import React from 'react'
import { GameContainer } from './components/GameContainer'
import { ConversationDialog } from './components/ConversationDialog'
import { IntroScreen } from './components/IntroScreen'
import { GameLogicOverlay } from './components/GameLogicOverlay'
import CaseBoard from './components/CaseBoard'
import { useGameStore } from './store/gameStore'
import './App.css'
import EvidenceInspector from './components/EvidenceInspector'

function DiscoveryToast(){
  const toast=useGameStore(s=>s.discoveryToast)
  if(!toast) return null
  return <div className="discovery-toast" dir="rtl"><div className="discovery-icon">⌕</div><div><span>دليل جديد</span><p>{toast}</p></div></div>
}

export default function App(){
  const caseBoardOpen=useGameStore(s=>s.caseBoardOpen)
  return <div className="app" dir="rtl">
    <div className="paper-texture"/>
    <div className="cinema-vignette"/>
    <GameContainer/>
    <DiscoveryToast/>
    <GameLogicOverlay/>
    {caseBoardOpen && <CaseBoard onClose={()=>useGameStore.getState().setCaseBoardOpen(false)}/>}
    <ConversationDialog/>
    <EvidenceInspector/>
    <IntroScreen/>
  </div>
}
