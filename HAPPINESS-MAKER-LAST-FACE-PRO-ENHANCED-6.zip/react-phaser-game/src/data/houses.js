// بيانات اللعبة — النسخة العربية الفصحى
const createDialog = (text, options = []) => ({ text, options })

const chat = { label: "🔎 استجوب أكثر", action: "chat" }

const day1_1 = createDialog("جئت تبحث عن كريم، أليس كذلك؟", [
  { label: "متى رأيت كريم للمرة الأخيرة؟", response: "أمس عند الغروب، كان بالقرب من الغابة." , nextDialog: createDialog("أمس عند الغروب، كان بالقرب من الغابة.", [
    { label: "هل كان وحده؟", response: "نعم... لكنه كان ينظر إلى ياسين بطريقة غريبة." },
    { label: "لماذا ياسين؟", response: "لا أعلم. ياسين أيضاً تصرف وكأنه لا يعرفه." }
  ])},
  { label: "كيف يبدو لك ياسين؟", response: "غريب. عادةً يكون هادئاً، لكنه اليوم يراقب الجميع.", nextDialog: createDialog("يراقب؟", [
    { label: "يراقب من؟", response: "كل واحد منا... كذئب ينتظر فريسته." }
  ])},
  { label: "حسناً، شكراً.", response: "احذر من الغابة ليلاً." }, chat
])

const day1_2 = createDialog("كريم اختفى... نسأل الله أن يحفظه.", [
  { label: "هل عالجته قبل أن يختفي؟", response: "نعم. جاء إليّ وهو خائف من شيء ما.", nextDialog: createDialog("ممَّ كان خائفاً؟", [
    { label: "من نفسه؟", response: "لا. قال لي: «لم يعد هذا الجلد جلدي»." }
  ])},
  { label: "هل رأيت ياسين؟", response: "مر بجانبي ولم يسلّم عليّ.", nextDialog: createDialog("أليس هذا غريباً؟", [
    { label: "لماذا؟", response: "لأنه لم يفعل ذلك من قبل. مرّ أمامي وكأنه لم يرني." }
  ])},
  { label: "احذري على نفسك.", response: "أنا دائماً حذرة." }, chat
])

const day1_3 = createDialog("ماذا تريد أيها الحارس؟", [
  { label: "أين كنت ليلة أمس؟", response: "كنت في الغابة أبحث عن الصيد.", nextDialog: createDialog("عن ماذا كنت تبحث؟", [
    { label: "عن حيوان؟", response: "عن لحم طازج... ليس هذا وقت كثرة الأسئلة." }
  ])},
  { label: "هل رأيت كريم؟", response: "كريم؟ لقد اختفى. كان ضعيفاً جداً.", nextDialog: createDialog("لا تبدو خائفاً عليه.", [
    { label: "لماذا؟", response: "في القرية، على الضعيف أن يبقى حذراً." }
  ])},
  { label: "تبدو مختلفاً اليوم.", response: "ربما بدأت أنت فقط ترى الأشياء كما هي." },
  { label: "حسناً.", response: "اذهب في طريقك." }, chat
])

const day1_4 = createDialog("لماذا تنظر إليّ هكذا؟", [
  { label: "أنا أطرح الأسئلة فقط.", response: "كان ياسين واقفاً قرب نافذتي ليلة أمس.", nextDialog: createDialog("ماذا كان يفعل؟", [
    { label: "والو؟", response: "لا شيء... كان واقفاً ويتنفس فقط. وهذا تحديداً ما أخافني." }
  ])},
  { label: "هل أنت بخير؟", response: "أشعر بالبرد رغم أنني بجوار النار. لا أعرف لماذا." },
  { label: "أغلقي الباب جيداً.", response: "سأغلقه الآن." }, chat
])

const day1_5 = createDialog("في الهواء اليوم رائحة موت.", [
  { label: "ربما هي رائحة الغابة فقط.", response: "لا. إنها رائحة موت قديم... مخبأ تحت شيء جديد.", nextDialog: createDialog("مخبأ تحت ماذا؟", [
    { label: "تحت جلد جديد.", response: "بالضبط. لا تثق بعينيك." }
  ])},
  { label: "استرح يا حاج.", response: "لم يعد هناك وقت للراحة." }, chat
])

const day2_1 = createDialog("رأيته! رأيته بعيني! رأيته أمس!", [
  { label: "اهدأ... من رأيت؟", response: "ياسين! تحدث معي وضحك معي!", nextDialog: createDialog("تحدث معك؟", [
    { label: "ماذا قال؟", response: "قال لي: «الطحين اليوم جيد». لكن الطبيب يقول إنه ميت منذ مدة!" },
    { label: "هل أنت متأكد؟", response: "لو لم أره بعيني، لقلت إنني أحلم." }
  ])},
  { label: "إذا كان ميتاً...", response: "فمن كان في منزله إذن؟!" , nextDialog: createDialog("شيء ليس بشراً.", [
    { label: "ما هو؟", response: "إنه يرتدي وجوه الناس... ويعيش بيننا." }
  ])},
  { label: "ابق في المنزل.", response: "لن أخرج." }, chat
])

const day2_2 = createDialog("هذا لا يدخل العقل.", [
  { label: "اشرح لي ماذا وجدت.", response: "كانت جثة ياسين متحللة بشكل واضح.", nextDialog: createDialog("منذ متى كان ميتاً؟", [
    { label: "تقريباً؟", response: "منذ 48 ساعة على الأقل... أي قبل أمس." },
    { label: "لكننا تحدثنا معه.", response: "تحدثنا مع جلده... لا مع ياسين." }
  ])},
  { label: "إذن، ما الذي رأيناه؟", response: "مخلوق يتقمص الناس. وهو اليوم بيننا." },
  { label: "سأبحث عنه.", response: "ابحث عمّن تغيّر فجأة." }, chat
])

const day2_4 = createDialog("الصباح جميل اليوم، أليس كذلك؟", [
  { label: "تبدين سعيدة جداً.", response: "ولماذا لا؟ الشمس دافئة.", nextDialog: createDialog("لكن ياسين مات.", [
    { label: "حقاً؟", response: "الناس يموتون... هذه هي الحياة." },
    { label: "كنتِ خائفة جداً بالأمس.", response: "كنت؟ لم يعد الخوف نفسه موجوداً في داخلي اليوم." }
  ])},
  { label: "ماذا تعملين؟", response: "أعمل على ثوب... للحفلة.", nextDialog: createDialog("ولماذا لا تستطيعين أن تشرحي لي النقشة؟", [
    { label: "هل نسيتِ؟", response: "ربما... إنها مجرد خيوط." }
  ])},
  { label: "ابق هنا.", response: "سأبقى." }, chat
])

const day2_5 = createDialog("الشيء الذي يبحث عن وجوهنا غيّر جلده.", [
  { label: "هل كان ياسين الضحية؟", response: "كان مجرد واحد من الوجوه التي استخدمها." },
  { label: "ومن الآن؟", response: "استمع إلى الصوت... إلى الكلمات... وإلى الخوف، سواء ظهر أم اختفى.", nextDialog: createDialog("ما الذي يجب أن ألاحظه؟", [
    { label: "التغيّر الذي يحدث خلال يوم واحد.", response: "الخوف الحقيقي لا يختفي في ليلة واحدة." }
  ])},
  { label: "سأجده.", response: "أسرع قبل حلول الليل." }, chat
])

const day3_1 = createDialog("مريم... ليست مريم.", [
  { label: "مريم ماتت.", response: "ماتت منذ يومين... يومين كاملين!" },
  { label: "لكنني تحدثت إليها بالأمس.", response: "إذن، من تحدثت إليه لم يكن هي." }
])
const day3_2 = createDialog("النمط نفسه يتكرر.", [
  { label: "مريم؟", response: "كانت الجثة ميتة قبل أمس. ولم يبق فيها شيء." },
  { label: "هل كان شيء ما يقلدها؟", response: "نعم. وحتى أبسط تفاصيل حياتها لم تعرفها." }
])
const day3_5 = createDialog("وجهان تغيّرا.", [
  { label: "من بقي؟", response: "من لا يزال قادراً على مواجهة هذا الشيء." },
  { label: "هل أنت هو؟", response: "لو كنت هو، لما بقيت تتحدث الآن." }
])
const day4_1 = createDialog("هل أنت هو؟ ولا أنا؟", [
  { label: "الحاج عمر مات.", response: "لم يبقَ سوى اثنين... أنا وأنت." },
  { label: "أحدنا هو المخلوق.", response: "أعرف. وأنا أيضاً أراقبك." }, chat
])
const day4_2 = createDialog("هذه هي التجربة الأخيرة.", [
  { label: "لم يبقَ سوى اثنين.", response: "نعم. والشيء الذي يبحث عن وجوهنا هو أحدنا." },
  { label: "كيف نعرف؟", response: "لا أملك الجواب... وهذا هو الجزء المخيف." }, chat
])

export const houses = [
  { id:"house_corin", type:"villager", x:1500,y:210,image:"house4",status:"missing",altImage:"house4-infected",infectedImage:"assets/first-house.png",npc:{name:"دار كريم",portrait:null,dialog:[]} },
  { id:"guard_house", type:"guard", x:860,y:280,image:"house5",status:"normal",npc:{name:"الحارس — أنت",portrait:"assets/male1_mod.png",dialog:[{text:"اقترب الليل... هل تريد أن ترتاح حتى الصباح؟",options:[{label:"😴 نعس حتى للصباح",action:"sleep",response:"حسناً، حفظك الله."},{label:"🔪 اتهم شي واحد",action:"eliminate",response:"من تشك فيه؟"},{label:"عودة",action:"close",response:"كن حذراً."}]}]}},
  { id:"house_1",type:"villager",x:80,y:1100,image:"house2",status:"normal",altImage:"house2-infected",infectedImage:"assets/murder-house1.png",day1:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day1_1]}},day2:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day2_1]}},day3:{npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day3_1]}},npc:{name:"إسماعيل — الطحّان",portrait:"assets/male1_mod.png",dialog:[day1_1]}},
  { id:"house_2",type:"villager",x:80,y:450,image:"house",status:"normal",altImage:"murder-house1",infectedImage:"assets/murder-house2.png",day1:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day1_2]}},day2:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day2_2]}},day3:{npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day3_2]}},npc:{name:"أمينة — العشّابة",portrait:"assets/female1_mod.png",dialog:[day1_2]}},
  { id:"house_3",type:"villager",x:1490,y:700,image:"house3",status:"normal",altImage:"house3-infected",infectedImage:"assets/murder-house3.png",day1:{npc:{name:"ياسين — الصيّاد",portrait:"assets/male2_mod.png",dialog:[day1_3]}},day2:{npc:null,status:"dead",infectedImage:"assets/murder-house3.png"},day3:{npc:null,status:"dead",infectedImage:"assets/murder-house3.png"},npc:{name:"ياسين — الصيّاد",portrait:"assets/male2_mod.png",dialog:[day1_3]}},
  { id:"house_4",type:"villager",x:1300,y:1100,image:"house2",status:"normal",altImage:"murder-house2",infectedImage:"assets/murder-house1.png",day1:{npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day1_4]}},day2:{npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day2_4]}},day3:{npc:null,status:"dead",infectedImage:"assets/murder-house2.png"},npc:{name:"مريم — الخيّاطة",portrait:"assets/female2_mod.png",dialog:[day1_4]}},
  { id:"house_5",type:"villager",x:900,y:800,image:"house3",status:"normal",altImage:"murder-house3",infectedImage:"assets/murder-house2.png",day1:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day1_5]}},day2:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day2_5]}},day3:{npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day3_5]}},npc:{name:"الحاج عمر",portrait:"assets/male22_mod.png",dialog:[day1_5]}}
]
