import Phaser from 'phaser'
import { AssetLoader } from '../utils/AssetLoader'
import { HouseManager } from '../utils/HouseManager'
import { InteractionManager } from '../utils/InteractionManager'
import { useGameStore } from '../../store/gameStore'

export class VillageScene extends Phaser.Scene {
 constructor(){super({key:'VillageScene'});this.assetLoader=null;this.houseManager=null;this.interactionManager=null;this.fx=[]}
 preload(){this.assetLoader=new AssetLoader(this);this.assetLoader.preload()}
 create(){
  this.assetLoader.createPlaceholders()
  const bg=this.add.image(0,0,'village-bg').setOrigin(0,0).setDisplaySize(1600,989).setDepth(-20)
  this.add.rectangle(800,1095,1600,410,0x241510,.55).setDepth(-19)
  this.physics.world.setBounds(0,0,1600,1200);this.cameras.main.setBounds(0,0,1600,1200)
  this.createAtmosphere()
  this.createHud()
  const {houses}=useGameStore.getState();this.houseManager=new HouseManager(this,null,houses);const data=this.houseManager.create();this.interactionManager=new InteractionManager(this,data,this.houseManager);this.interactionManager.create()
  this.events.once('shutdown',()=>this.cleanup())
 }
 createAtmosphere(){
  const glow=this.add.circle(1375,145,105,0xf0d2b9,.055).setDepth(-5)
  this.tweens.add({targets:glow,alpha:.025,scale:1.15,duration:3600,yoyo:true,repeat:-1,ease:'Sine.easeInOut'})
  const fog=this.add.graphics().setDepth(5000);fog.fillStyle(0x17100e,.16);fog.fillRect(0,0,1600,1200)
  for(let i=0;i<18;i++){
   const x=Phaser.Math.Between(40,1560),y=Phaser.Math.Between(250,1100)
   const mote=this.add.circle(x,y,Phaser.Math.Between(1,3),0xf0c7aa,.16).setDepth(5500)
   this.tweens.add({targets:mote,x:x+Phaser.Math.Between(-45,45),y:y-Phaser.Math.Between(30,90),alpha:0,duration:Phaser.Math.Between(2400,5200),repeat:-1,yoyo:true,delay:i*180})
   this.fx.push(mote)
  }
  const topShade=this.add.graphics().setDepth(6000);topShade.fillGradientStyle(0x1b0e0a,.42,0x1b0e0a,0,0x1b0e0a,.08,0x1b0e0a,.0);topShade.fillRect(0,0,1600,260)
 }
 createHud(){
  const g=this.add.graphics().setDepth(8500);g.fillStyle(0x211411,.62);g.fillRoundedRect(28,24,390,82,18);g.lineStyle(1,0xe8c6b3,.22);g.strokeRoundedRect(28,24,390,82,18)
  this.add.text(52,42,'الوجه الأخير',{fontFamily:'Arial',fontSize:'25px',fontStyle:'bold',color:'#f6dfd3'}).setDepth(8501)
  this.add.text(52,75,'ملف التحقيق 001  •  كل تفصيل قد يكون دليلاً',{fontFamily:'Arial',fontSize:'12px',color:'#cba99b'}).setDepth(8501)
  const night=this.add.text(1520,48,'الليلة 01',{fontFamily:'Arial',fontSize:'18px',fontStyle:'bold',color:'#f3d8cb',backgroundColor:'#211411',padding:{left:15,right:15,top:9,bottom:9}}).setOrigin(1,0).setDepth(8501)
  useGameStore.subscribe(s=>night.setText(`الليلة 0${Math.min(s.cycle,4)}`))
  this.add.text(800,1138,'اضغط على المنزل لفحصه   •   اسحب الشاشة لاستكشاف القرية',{fontFamily:'Arial',fontSize:'13px',color:'#ead0c3',backgroundColor:'#241713',padding:{left:18,right:18,top:9,bottom:9}}).setOrigin(.5).setDepth(8501).setAlpha(.9)
 }
 cleanup(){this.fx.forEach(x=>x?.destroy());this.fx=[]}
 update(){try{if(useGameStore.getState().isPaused)return;if(this.interactionManager)this.interactionManager.update()}catch(error){console.error('VillageScene.update',error)}}
}
