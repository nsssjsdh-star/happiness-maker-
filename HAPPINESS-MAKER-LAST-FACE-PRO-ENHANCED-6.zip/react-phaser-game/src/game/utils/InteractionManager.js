import Phaser from 'phaser'
import { useGameStore } from '../../store/gameStore'

export class InteractionManager {
  constructor(scene, houseData, houseManager){this.scene=scene;this.houseData=houseData;this.houseManager=houseManager;this.selectedIndex=0;this.cursorIcon=null;this.cursorRing=null;this.label=null;this.keys=null}
  create(){
    this.cursorRing=this.scene.add.graphics().setDepth(9000)
    this.cursorIcon=this.scene.add.text(0,0,'⌕',{fontFamily:'Georgia, serif',fontSize:'34px',fontStyle:'bold',color:'#fff1e8',stroke:'#2a1711',strokeThickness:6}).setDepth(9001).setOrigin(.5)
    this.label=this.scene.add.text(0,0,'',{fontFamily:'Arial',fontSize:'18px',fontStyle:'bold',color:'#fff7f0',backgroundColor:'#6b3c2c',padding:{left:12,right:12,top:7,bottom:7}}).setDepth(9002).setOrigin(.5,1).setAlpha(0)
    if(this.scene.input.keyboard){this.keys=this.scene.input.keyboard.addKeys({up:Phaser.Input.Keyboard.KeyCodes.W,down:Phaser.Input.Keyboard.KeyCodes.S,left:Phaser.Input.Keyboard.KeyCodes.A,right:Phaser.Input.Keyboard.KeyCodes.D,interact:Phaser.Input.Keyboard.KeyCodes.E,interact2:Phaser.Input.Keyboard.KeyCodes.SPACE,arrowUp:Phaser.Input.Keyboard.KeyCodes.UP,arrowDown:Phaser.Input.Keyboard.KeyCodes.DOWN,arrowLeft:Phaser.Input.Keyboard.KeyCodes.LEFT,arrowRight:Phaser.Input.Keyboard.KeyCodes.RIGHT})}
    this.selectHouse(0)
    this.scene.input.on('pointerdown',this.handleMouseClick,this)
    this.houseData.forEach((house,index)=>house.sprite.on('pointerover',()=>{if(!useGameStore.getState().isPaused)this.selectHouse(index)}))
  }
  update(){
    const state=useGameStore.getState();if(state.isPaused)return
    if(!this.keys)return
    if(Phaser.Input.Keyboard.JustDown(this.keys.right)||Phaser.Input.Keyboard.JustDown(this.keys.arrowRight))this.moveSelection(1,0)
    else if(Phaser.Input.Keyboard.JustDown(this.keys.left)||Phaser.Input.Keyboard.JustDown(this.keys.arrowLeft))this.moveSelection(-1,0)
    else if(Phaser.Input.Keyboard.JustDown(this.keys.up)||Phaser.Input.Keyboard.JustDown(this.keys.arrowUp))this.moveSelection(0,-1)
    else if(Phaser.Input.Keyboard.JustDown(this.keys.down)||Phaser.Input.Keyboard.JustDown(this.keys.arrowDown))this.moveSelection(0,1)
    if(Phaser.Input.Keyboard.JustDown(this.keys.interact)||Phaser.Input.Keyboard.JustDown(this.keys.interact2)){const h=this.houseData[this.selectedIndex];if(h)useGameStore.getState().openHouseEvent(h.id)}
    const h=this.houseData[this.selectedIndex]
    if(h&&this.cursorIcon){const hh=(h.sprite.height*h.sprite.scaleY)/2;const y=h.y-hh-30;this.cursorIcon.setPosition(h.x,y+Math.sin(this.scene.time.now/220)*3);this.cursorRing.clear();this.cursorRing.lineStyle(4,0xf0c8b5,.9);this.cursorRing.strokeCircle(h.x,h.y,Math.max(70,h.sprite.displayWidth*.48));this.cursorRing.lineStyle(2,0x2d1812,.7);this.cursorRing.strokeCircle(h.x,h.y,Math.max(82,h.sprite.displayWidth*.57));if(this.label){this.label.setText(h.status==='normal'?'فحص المكان':h.status==='dead'?'دليل مهم':'تحقيق');this.label.setPosition(h.x,y-34);this.label.setAlpha(1)}}
  }
  moveSelection(dx,dy){const current=this.houseData[this.selectedIndex];let best=-1,bestScore=Infinity;this.houseData.forEach((house,index)=>{if(index===this.selectedIndex)return;const vx=house.x-current.x,vy=house.y-current.y,dot=vx*dx+vy*dy;if(dot>0){const score=(vx*vx+vy*vy)/(dot*dot);if(score<bestScore){bestScore=score;best=index}}});if(best!==-1)this.selectHouse(best)}
  selectHouse(index){const previous=this.houseData[this.selectedIndex];if(previous&&this.houseManager)this.houseManager.restoreVisual(previous);this.selectedIndex=index;const h=this.houseData[index];if(h){this.scene.cameras.main.pan(h.x,h.y,450,'Power2');this.scene.tweens.add({targets:h.sprite,scaleX:.53,scaleY:.53,duration:140,yoyo:true,ease:'Sine.easeOut'});}}
  handleMouseClick(pointer){if(useGameStore.getState().isPaused)return;const worldX=this.scene.cameras.main.scrollX+pointer.x,worldY=this.scene.cameras.main.scrollY+pointer.y;let clicked=-1,min=130;this.houseData.forEach((h,i)=>{const d=Phaser.Math.Distance.Between(worldX,worldY,h.x,h.y);if(d<min){min=d;clicked=i}});if(clicked!==-1){this.selectHouse(clicked);useGameStore.getState().openHouseEvent(this.houseData[clicked].id)}}
}
