export class AssetLoader {
  constructor(scene){this.scene=scene;this.failedAssets=new Set()}
  preload(){
    this.scene.load.on('loaderror',file=>this.failedAssets.add(file.key))
    this.scene.load.image('village-bg','/assets/smth.png')
    const assets={
      house:'/assets/house.png',house2:'/assets/house2.png',house3:'/assets/house3.png',house4:'/assets/house4.png',house5:'/assets/house5.png',
      'house1-infected':'/assets/murder-house1.png','house2-infected':'/assets/murder-house2.png','house3-infected':'/assets/murder-house3.png','house4-infected':'/assets/murder-house4.png',
      'house6-infected':'/assets/murder-house2.png','house7-infected':'/assets/murder-house3.png','house6':'/assets/house2.png','house7':'/assets/house3.png','house1':'/assets/house.png'
    }
    Object.entries(assets).forEach(([key,path])=>this.scene.load.image(key,path))
  }
  createPlaceholders(){
    const g=this.scene.add.graphics()
    if(!this.scene.textures.exists('village-bg')){g.fillStyle(0x8d6250,1);g.fillRect(0,0,1600,1200);g.generateTexture('village-bg',1600,1200);g.clear()}
    for(const [key,color] of [['house',0x9b624b],['house2',0x7e5342],['house3',0x6c4639]]){
      if(!this.scene.textures.exists(key)){g.fillStyle(color,1);g.fillRect(10,20,60,60);g.fillStyle(0x5b372c,1);g.fillTriangle(40,0,0,20,80,20);g.fillStyle(0x3f2922,1);g.fillRect(30,50,20,30);g.generateTexture(key,80,80);g.clear()}
    }
    g.destroy()
  }
}
