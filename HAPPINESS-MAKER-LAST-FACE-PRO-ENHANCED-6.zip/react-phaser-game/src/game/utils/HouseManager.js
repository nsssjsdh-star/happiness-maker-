import { useGameStore } from '../../store/gameStore'

export class HouseManager {
 constructor(scene,player,houses){this.scene=scene;this.player=player;this.houses=houses;this.houseSprites=[];this.houseData=[];this.housesById=new Map();this.indicators=new Map()}
 create(){
  this.houses.forEach(config=>{
   const group=this.scene.physics.add.staticGroup();const sprite=group.create(config.x,config.y,config.image);sprite.setOrigin(.5,.5).setScale(.5);sprite.setInteractive({useHandCursor:true});
   const data={id:config.id,type:config.type,x:config.x,y:config.y,status:config.status,altImage:config.altImage,originalImage:config.image,sprite,width:sprite.width,height:sprite.height};
   this.houseSprites.push(group);this.houseData.push(data);this.housesById.set(data.id,data);if(this.player)this.scene.physics.add.collider(this.player,group);this.updateHouseVisual(data)
  });
  useGameStore.subscribe(state=>this.updateAllVisuals(state.houses));return this.houseData
 }
 updateAllVisuals(houses){houses.forEach(updated=>{const current=this.housesById.get(updated.id);if(current){current.status=updated.status;this.updateHouseVisual(current)}})}
 restoreVisual(data){if(!data?.sprite)return;data.sprite.setTexture(data.originalImage||data.sprite.texture.key);data.sprite.setScale(.5);data.sprite.clearTint()}
 updateHouseVisual(data){
  if(this.indicators.has(data.id)){this.indicators.get(data.id).destroy();this.indicators.delete(data.id)}
  data.sprite.setTexture(data.originalImage||data.sprite.texture.key).setScale(.5).clearTint()
  if(data.status!=='normal'&&data.altImage&&this.scene.textures.exists(data.altImage))data.sprite.setTexture(data.altImage)
  if(data.status==='dead'){data.sprite.setTint(0x77706a)}
  if(data.status==='missing'){const marker=this.scene.add.text(data.x,data.y-100,'؟',{fontFamily:'Georgia',fontSize:'52px',fontStyle:'bold',color:'#f6dfd1',stroke:'#5a3024',strokeThickness:7}).setOrigin(.5).setDepth(8000);this.scene.tweens.add({targets:marker,y:data.y-116,alpha:.5,duration:900,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});this.indicators.set(data.id,marker)}
 }
 getAllHouses(){return this.houseData}
 getHouseById(id){return this.housesById.get(id)||null}
}
