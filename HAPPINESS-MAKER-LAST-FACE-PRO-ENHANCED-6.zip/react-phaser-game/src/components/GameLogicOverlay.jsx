import React from 'react'
import { useGameStore } from '../store/gameStore'
import { FailScreen } from './FailScreen'
import { WinScreen } from './WinScreen'
import './Elimination.css'

export function GameLogicOverlay() {
  const { houses, hasWon, hasLost, eliminationMode, eliminateVillager, setEliminationMode, endGameMessage, cycle } = useGameStore()
  if (hasWon) return <WinScreen message={endGameMessage} />
  if (hasLost) return <FailScreen message={endGameMessage} />
  const normalCount = houses.filter(h => h.type === 'villager' && h.status === 'normal').length
  if ((normalCount <= 1 && !hasWon) || (cycle > 4 && normalCount >= 2)) return <FailScreen message="لم تصل إلى الحقيقة في الوقت المناسب. المخلوق ما زال حراً." />
  if (!eliminationMode) return null
  const survivors = houses.filter(h => h.type === 'villager' && h.status === 'normal')
  return <div className="elimination-overlay" dir="rtl"><div className="elimination-content"><div className="decision-symbol">◆</div><div className="case-label">قرار نهائي • ملف 001</div><h2>من يختبئ خلف هذا الوجه؟</h2><p>لا تتخذ القرار إلا إذا جمعت ما يكفي من الأدلة. اتهام الشخص الخطأ ينهي التحقيق.</p><div className="suspect-list">{survivors.map(h => <button key={h.id} className="suspect-btn" onClick={() => eliminateVillager(h.id)}><span>{h.npc?.name || 'مشتبه به'}</span><i>اتهام</i></button>)}</div><button className="cancel-btn" onClick={() => setEliminationMode(false)}>العودة إلى التحقيق</button></div></div>
}
