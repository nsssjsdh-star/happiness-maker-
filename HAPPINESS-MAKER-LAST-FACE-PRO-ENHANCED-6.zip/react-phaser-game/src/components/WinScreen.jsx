import React from 'react'
import './WinScreen.css'
export function WinScreen({ message }) { return <div className="win-screen-overlay" dir="rtl"><div className="win-content"><div className="win-icon">✓</div><div className="win-kicker">تم إغلاق القضية</div><h1>لقد نجحت</h1><p className="win-message">{message || 'كشفت الحقيقة قبل أن يضيع آخر خيط في القضية.'}</p><button className="reset-button" onClick={() => window.location.reload()}>بدء تحقيق جديد</button></div></div> }
