import React from 'react'
import { useGameStore } from '../store/gameStore'
import './EvidenceInspector.css'

const spots = {
  house_corin: [
    { id:'footprints', x:18, y:72, title:'أثر الأقدام', text:'آثار أقدام تبدأ قرب الغابة ثم تتوقف أمام الباب دون أن تتجه إلى أي مكان آخر.' },
    { id:'door', x:67, y:45, title:'قفل الباب', text:'القفل سليم، لكن عليه خدش حديث من الداخل. لا يبدو أن الباب كُسر بالقوة.' },
    { id:'mark', x:82, y:23, title:'العلامة على الجدار', text:'نقش صغير يشبه وجهاً غير مكتمل. يبدو أنه رُسم حديثاً.' }
  ],
  house_1: [
    { id:'flour', x:26, y:58, title:'كيس الطحين', text:'الغبار يغطي الكيس كله، باستثناء مكان واحد على شكل أصابع.' },
    { id:'window', x:76, y:30, title:'النافذة', text:'النافذة مغلقة من الداخل، لكن على حافتها خيوط قماش داكنة.' },
    { id:'clock', x:61, y:69, title:'الساعة', text:'تعمل بشكل طبيعي، لكن عقرب الثواني يتوقف لثوانٍ ثم يتحرك دفعة واحدة.' }
  ],
  house_2: [
    { id:'herbs', x:25, y:64, title:'رف الأعشاب', text:'بين الأعشاب ورقة صغيرة تحمل تاريخاً أقدم من عمر الحادثة.' },
    { id:'cloth', x:72, y:34, title:'قطعة القماش', text:'الخيط نفسه الذي ظهر في ثوب مريم موجود هنا.' },
    { id:'cup', x:58, y:72, title:'الكوب', text:'الكوب دافئ رغم أن النار انطفأت منذ وقت طويل.' }
  ],
  house_3: [
    { id:'clock', x:68, y:35, title:'ساعة الصياد', text:'العقارب متوقفة عند وقت الوفاة المزعوم، مع أن آلية الساعة سليمة.' },
    { id:'boots', x:25, y:72, title:'الحذاء', text:'آثار طين حديثة على الحذاء، رغم أن ياسين كان يفترض أنه لم يخرج.' },
    { id:'wall', x:82, y:68, title:'الجدار', text:'خدوش متوازية على الخشب، وكأن شيئاً حاداً مرّ عليه عدة مرات.' }
  ],
  house_4: [
    { id:'dress', x:61, y:36, title:'الثوب', text:'النقشة ليست زخرفة عادية. تتكرر فيها أربعة أشكال تشبه الوجوه.' },
    { id:'needle', x:27, y:67, title:'الإبرة', text:'الإبرة عالقة في الخيط نفسه الذي ظهر في منزل أمينة.' },
    { id:'mirror', x:80, y:27, title:'المرآة', text:'في الصورة المنعكسة يظهر جزء من الغرفة لا يطابق زاوية المرآة.' }
  ],
  house_5: [
    { id:'book', x:27, y:35, title:'دفتر الحاج عمر', text:'كتب: «لا أخاف من الذي يختبئ في الظلام، بل من الذي يبتسم في الضوء.»' },
    { id:'lantern', x:72, y:66, title:'الفانوس', text:'فتيله جديد، لكنه لم يُشعل منذ أيام بحسب طبقة الغبار حوله.' },
    { id:'chair', x:51, y:72, title:'الكرسي', text:'هناك أثر ضغط حديث على الكرسي، وكأن شخصاً جلس فيه قبل دقائق.' }
  ],
  guard_house: [
    { id:'map', x:25, y:36, title:'خريطة القرية', text:'علامة حمراء تحيط بالمنازل التي تغيّر أصحابها خلال الأيام الماضية.' },
    { id:'radio', x:72, y:39, title:'جهاز الاتصال', text:'تسجيل قصير التقط صوتاً في الخلفية لا يشبه صوت أي شخص في القرية.' },
    { id:'keys', x:54, y:72, title:'المفاتيح', text:'مفتاح واحد ليس من مفاتيح القرية. الرقم المحفور عليه: 13.' }
  ]
}

export default function EvidenceInspector(){
  const { currentHouse, inspectionOpen, closeInspection, inspectSpot, inspectedSpots, cycle } = useGameStore()
  if(!inspectionOpen || !currentHouse) return null
  const list = spots[currentHouse.id] || spots.house_5
  const imageName = currentHouse.image || 'house'
  const imageSrc = `/assets/${imageName}.png`
  const keyPrefix = `${cycle}:${currentHouse.id}:`
  const found = list.filter(s => inspectedSpots[`${keyPrefix}${s.id}`]).length
  return <div className="inspector-overlay" dir="rtl" role="dialog" aria-modal="true">
    <div className="inspector-shell">
      <header className="inspector-head">
        <div>
          <span>وضع التحقيق • الليلة {String(cycle).padStart(2,'0')}</span>
          <h2>فحص المكان</h2>
          <p>{currentHouse.npc?.name || 'الموقع'} — ابحث عن التفاصيل التي لا تبدو في مكانها.</p>
        </div>
        <button className="inspector-close" onClick={closeInspection} aria-label="إغلاق">×</button>
      </header>
      <div className="inspector-main">
        <div className="scene-frame">
          <img src={imageSrc} alt="الموقع" onError={(e)=>{e.currentTarget.style.display='none'}} />
          <div className="scene-wash"/>
          {list.map((spot,i)=>{
            const isFound=!!inspectedSpots[`${keyPrefix}${spot.id}`]
            return <button key={spot.id} className={`evidence-hotspot ${isFound?'found':''}`} style={{left:`${spot.x}%`,top:`${spot.y}%`}} onClick={()=>inspectSpot(currentHouse.id,spot)} aria-label={spot.title}>
              <span>{isFound?'✓':String(i+1).padStart(2,'0')}</span>
            </button>
          })}
          <div className="scan-line"/>
        </div>
        <aside className="inspector-panel">
          <div className="panel-progress"><span>الأدلة المكتشفة</span><b>{found}/{list.length}</b></div>
          <div className="panel-track"><i style={{width:`${(found/list.length)*100}%`}}/></div>
          <p className="panel-tip">اضغط على العلامات داخل المشهد. بعض الأدلة لا تبدو واضحة من النظرة الأولى.</p>
          <div className="spot-list">
            {list.map((spot,i)=>{const isFound=!!inspectedSpots[`${keyPrefix}${spot.id}`];return <div className={`spot-row ${isFound?'found':''}`} key={spot.id}><span>{isFound?'✓':String(i+1).padStart(2,'0')}</span><div><b>{isFound?spot.title:'تفصيل غير مكتشف'}</b><p>{isFound?spot.text:'افحص هذا الجزء من المكان.'}</p></div></div>})}
          </div>
          <button className="inspector-done" onClick={closeInspection}>العودة إلى التحقيق</button>
        </aside>
      </div>
    </div>
  </div>
}
