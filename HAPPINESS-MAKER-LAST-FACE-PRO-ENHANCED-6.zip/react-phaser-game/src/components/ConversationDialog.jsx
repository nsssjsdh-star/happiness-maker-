import React, { useState, useEffect, useRef } from 'react'
import { useGameStore } from '../store/gameStore'
import './ConversationDialog.css'

export function ConversationDialog() {
  const { currentHouse, closeHouseMenu, cycle, openInspection } = useGameStore()
  const [currentNode, setCurrentNode] = useState(null)
  const [chatHistory, setChatHistory] = useState([])
  const [chatInput, setChatInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const chatEndRef = useRef(null)
  const isVillager = currentHouse?.type === 'villager'

  useEffect(() => {
    if (!currentHouse) return
    setChatHistory([])
    setChatInput('')
    if (!isVillager) {
      const dayKey = `day${cycle}`
      if (currentHouse[dayKey]?.npc?.dialog?.length) setCurrentNode(currentHouse[dayKey].npc.dialog[0])
      else if (currentHouse.npc?.dialog?.length) setCurrentNode(currentHouse.npc.dialog[0])
      else setCurrentNode(null)
    }
  }, [currentHouse, isVillager, cycle])

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chatHistory])
  if (!currentHouse) return null

  if (['infected', 'dead', 'missing'].includes(currentHouse.status)) {
    const npcName = currentHouse.npc?.name || 'المكان'
    let overlayText = ''
    if (currentHouse.status === 'dead') overlayText = `${npcName}... هناك شيء غير طبيعي. تبدو آثار الوفاة أقدم من الوقت الذي يرويه الشهود.`
    if (currentHouse.status === 'missing') overlayText = 'منزل كريم... لم يبقَ سوى هذه العلامة الغريبة. من تركها؟'
    if (currentHouse.status === 'infected') overlayText = `هناك شيء غير طبيعي في ${npcName}...`
    return <div className="infected-overlay" onClick={closeHouseMenu} dir="rtl"><div className="infected-content">{currentHouse.infectedImage && <img src={currentHouse.infectedImage} alt="دليل مرعب" className="infected-image-fullscreen" />}{overlayText && <p className="infected-overlay-text">{overlayText}</p>}<span className="tap-close">اضغط لإغلاق الدليل</span></div></div>
  }

  const handleOption = (option) => {
    if (option.action === 'sleep') return useGameStore.getState().sleep()
    if (option.action === 'eliminate') { useGameStore.getState().setEliminationMode(true); closeHouseMenu(); return }
    if (option.action === 'close') return closeHouseMenu()
    if (option.nextDialog) setCurrentNode(option.nextDialog)
    else if (option.response) setCurrentNode({ text: option.response, options: [{ label: 'إنهاء الحوار', action: 'close' }] })
  }

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if (!chatInput.trim() || isLoading) return
    const userMsg = chatInput.trim()
    setChatHistory(prev => [...prev, { sender: 'user', text: userMsg }])
    setChatInput('')
    setIsLoading(true)
    const answers = [
      'لا أعرف شيئاً عن ذلك... لكنني متأكد أن هناك شيئاً غير طبيعي في القرية.',
      'أخبرتك بما أعرفه. راقب التفاصيل الصغيرة، فهي تكشف ما تخفيه الوجوه.',
      'لم أرَ شيئاً واضحاً. إذا كنت تشك بي، فابحث عن دليل قبل أن تحكم.',
      'هناك أشياء لا أستطيع تفسيرها. اسألني عن الليلة التي اختفى فيها كريم.',
      'تذكّر: الشخص الذي أمامك قد لا يكون الشخص الذي تظنه.'
    ]
    const lower = userMsg.toLowerCase()
    let response = answers[(userMsg.length + cycle) % answers.length]
    if (lower.includes('كريم') || lower.includes('اختفاء')) response = 'رأيت كريم قرب الغابة عند الغروب. كان خائفاً، وكأنه رأى شيئاً لم يكن من المفترض أن يراه.'
    if (lower.includes('ياسين')) response = 'ياسين هو أول خيط واضح في القضية. المشكلة أن بعض الناس تحدثوا معه بعد الوقت الذي يفترض أنه مات فيه.'
    if (lower.includes('مريم')) response = 'كانت مريم تعرف شيئاً. بعد وفاتها، ظهرت تفاصيل جعلتني أشك في الشخص الذي كان يتحدث باسمها.'
    window.setTimeout(() => {
      setIsLoading(false)
      setChatHistory(prev => [...prev, { sender: 'npc', text: response }])
    }, 450)
  }

  const npc = currentHouse.npc
  const npcName = npc?.name || 'مشتبه فيه'
  const latestNpcMessage = chatHistory.filter(m => m.sender === 'npc').slice(-1)[0]?.text || 'اسألني. قد تكشف كلمة واحدة ما تبحث عنه.'

  if (isVillager) return (
    <div className="conversation-overlay" dir="rtl">
      <div className="conversation-dialog-box">
        <div className="dialog-left">
          {npc?.portrait ? <img src={npc.portrait} alt={npcName} className="dialog-portrait" /> : <div className="dialog-portrait-placeholder"><span>🏚️</span></div>}
        </div>
        <div className="dialog-right">
          <div className="dialog-response-area">
            <div className="dialog-tag">شخصية قيد التحقيق</div>
            <h3 className="dialog-npc-name">{npcName}</h3>
            <div className="dialog-response-text">{isLoading ? <em>يفكر في الإجابة...</em> : <p>{latestNpcMessage}</p>}</div>
            {chatHistory.slice(-4).map((m, i) => <div key={i} className={`chat-mini ${m.sender}`}>{m.text}</div>)}
            <div ref={chatEndRef} />
          </div>
          <div className="evidence-strip"><span>ملاحظة</span><b>{useGameStore.getState().evidence[0]?.text || 'راقب التناقضات بين كلام الشخص وما تراه في المكان.'}</b></div>
          <div className="dialog-input-area">
            <form onSubmit={handleSendMessage} className="dialog-input-form">
              <input dir="rtl" type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.stopPropagation()} placeholder="اكتب سؤالك هنا..." className="dialog-input" disabled={isLoading} autoFocus />
              <div className="dialog-buttons"><button type="submit" disabled={isLoading} className="dialog-btn dialog-btn-ask">إرسال</button><button type="button" onClick={openInspection} className="dialog-btn dialog-btn-inspect">فحص المكان</button><button type="button" onClick={closeHouseMenu} className="dialog-btn dialog-btn-leave">مغادرة</button></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )

  return <div className="conversation-overlay" dir="rtl"><div className="conversation-box"><div className="dialog-tag">مقر الحارس</div><h2 className="npc-name">{npcName}</h2><div className="dialog-text">{currentNode?.text || '...'}</div><div className="options-list">{currentNode?.options?.map((option, index) => <button key={index} className="dialog-option" onClick={() => handleOption(option)}>{option.label}</button>)}<button className="dialog-option dialog-inspect-option" onClick={openInspection}>🔎 فحص المكان والبحث عن دليل</button></div></div></div>
}
