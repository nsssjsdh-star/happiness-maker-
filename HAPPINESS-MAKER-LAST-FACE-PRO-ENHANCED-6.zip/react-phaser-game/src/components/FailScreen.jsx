import React from 'react'
import './FailScreen.css'
export function FailScreen({ message }) { return <div className="fail-screen-overlay"><div className="fail-content"><div className="fail-icon">×</div><div className="fail-kicker">القضية لم تُحل</div><h1>انتهى التحقيق</h1><p>{message || 'المخلوق ما زال حراً، ولم يعد لديك ما يكفي من الوقت.'}</p><button className="restart-button" onClick={() => window.location.reload()}>إعادة المحاولة</button></div></div> }
