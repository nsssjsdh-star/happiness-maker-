import React, {useMemo, useState} from 'react'
import { useGameStore } from '../store/gameStore'
import './Sidebar.css'

export default function Sidebar() {
  const { cycle, houses, evidence, setEliminationMode, setCaseBoardOpen } = useGameStore()
  const [tab, setTab] = useState('case')
  const contexts = {
    1:'اختفى كريم في ظروف غامضة. ابدأ بجمع الأدلة ولا تتسرع في الحكم.',
    2:'عُثر على ياسين ميتاً، لكن الشهادات لا تتفق مع وقت الوفاة.',
    3:'تكرر النمط. بعض الوجوه تبدو مألوفة، لكن سلوك أصحابها تغيّر.',
    4:'لم يبقَ سوى شخصين. كل دليل جمعته قد يحسم القضية.'
  }
  const living = houses.filter(h => h.type === 'villager' && h.status === 'normal')
  const progress = Math.min(cycle,4)*25
  const latest = useMemo(()=>evidence.slice(0,6),[evidence])
  return <aside className="sidebar-container" dir="rtl">
    <header className="sidebar-head">
      <div><div className="sidebar-brand">HAPPINESS MAKER</div><div className="sidebar-sub">وحدة التحقيقات الخاصة</div></div>
      <div className="status-dot"><i/> القضية مفتوحة</div>
    </header>
    <div className="case-title"><div className="case-kicker"><span>CASE 001</span><span>سري</span></div><h1>الوجه الأخير</h1><p>قرية معزولة • ملف اختفاءات متتابعة</p></div>
    <div className="night-card">
      <div className="night-row"><div><span>مرحلة التحقيق</span><b>الليلة {cycle} <em>/ 4</em></b></div><div className="night-mark">0{cycle}</div></div>
      <div className="progress"><i style={{width:`${progress}%`}}/></div>
      <p>{contexts[cycle]}</p>
    </div>
    <div className="tabs" role="tablist">
      <button className={tab==='case'?'active':''} onClick={()=>setTab('case')}>القضية <b>{String(evidence.length).padStart(2,'0')}</b></button>
      <button className={tab==='suspects'?'active':''} onClick={()=>setTab('suspects')}>المشتبه بهم <b>{living.length}</b></button>
    </div>
    {tab==='case' ? <section className="journal-section">
      <div className="section-heading"><span>لوحة الأدلة</span><b>{evidence.length}</b></div>
      <div className="journal-list">{latest.length===0 ? <div className="empty-note"><span>⌕</span><p>لم تجمع أي دليل بعد.<br/>افحص المنازل وابحث عن التفاصيل غير المعتادة.</p></div> : latest.map((entry,i)=><article key={entry.id} className="journal-entry"><div className="entry-pin">{i===0?'NEW':'•'}</div><div><div className="entry-meta">الليلة {entry.day} • ملاحظة تحقيق</div><p>{entry.text}</p></div></article>)}</div>
    </section> : <section className="journal-section"><div className="section-heading"><span>الأشخاص الباقون</span><b>{living.length}</b></div><div className="suspect-mini-list">{living.map(h=><div className="suspect-mini" key={h.id}><div className="mini-avatar">{h.npc?.name?.charAt(0) || '؟'}</div><div><b>{h.npc?.name || 'شخص مجهول'}</b><span>ما زال على قيد الحياة</span></div></div>)}</div></section>}
    <button className="board-button" onClick={() => setCaseBoardOpen(true)}><span>▦</span><div><b>فتح لوحة القضية</b><small>الأدلة والشخصيات والتسلسل الزمني</small></div><strong>←</strong></button>
    <button className="decision-button" onClick={() => setEliminationMode(true)}><span>⌁</span><div><b>اتخاذ قرار</b><small>الاتهام ينهي التحقيق إذا أخطأت</small></div><strong>←</strong></button>
    <div className="controls-hint"><span>◉</span><p>اضغط على أي منزل لفحصه.<br/>كل تفصيل صغير قد يغيّر نتيجة القضية.</p></div>
  </aside>
}
