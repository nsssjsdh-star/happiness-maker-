import React, {useMemo, useState} from 'react'
import {useGameStore} from '../store/gameStore'
import './CaseBoard.css'

export default function CaseBoard({onClose}){
  const {evidence,houses,cycle} = useGameStore()
  const [tab,setTab]=useState('evidence')
  const living=useMemo(()=>houses.filter(h=>h.type==='villager' && h.status==='normal'),[houses])
  const dead=useMemo(()=>houses.filter(h=>h.type==='villager' && h.status==='dead'),[houses])
  return <div className="caseboard-backdrop" dir="rtl">
    <section className="caseboard">
      <header className="caseboard-head">
        <div><span className="board-eyebrow">ملف التحقيق 001</span><h2>لوحة القضية</h2><p>اجمع الأدلة، قارن الشهادات، ولا تحكم قبل اكتمال الصورة.</p></div>
        <button className="board-close" onClick={onClose} aria-label="إغلاق">×</button>
      </header>
      <div className="board-status"><div><span>المرحلة الحالية</span><b>الليلة {cycle} من 4</b></div><div><span>الأدلة المكتشفة</span><b>{String(evidence.length).padStart(2,'0')}</b></div><div><span>المشتبه بهم الأحياء</span><b>{living.length}</b></div></div>
      <div className="board-tabs"><button className={tab==='evidence'?'active':''} onClick={()=>setTab('evidence')}>الأدلة</button><button className={tab==='people'?'active':''} onClick={()=>setTab('people')}>الأشخاص</button><button className={tab==='timeline'?'active':''} onClick={()=>setTab('timeline')}>التسلسل</button></div>
      {tab==='evidence' && <div className="evidence-grid">{evidence.length===0 ? <div className="board-empty"><strong>لم تُكتشف أدلة بعد</strong><p>افحص المنازل وتحدث مع السكان. بعض الأدلة لا تظهر إلا عند إعادة زيارة المكان.</p></div> : evidence.map((e,i)=><article className="evidence-card" key={e.id}><div className="evidence-number">{String(i+1).padStart(2,'0')}</div><div><span>الليلة {e.day} • دليل ميداني</span><h3>{e.title}</h3><p>{e.text}</p></div></article>)}</div>}
      {tab==='people' && <div className="people-grid">{[...living,...dead].map(h=><article className={`person-card ${h.status==='dead'?'dead':''}`} key={h.id}><div className="person-portrait">{h.npc?.portrait?<img src={h.npc.portrait} alt=""/>:<span>؟</span>}</div><div className="person-copy"><span>{h.status==='dead'?'متوفى':'مشتبه به'}</span><h3>{h.npc?.name||'شخص مجهول'}</h3><p>{h.status==='dead'?'لا يمكن استجوابه. ابحث في آثاره.':'ما زال موجوداً في القرية.'}</p></div><i>{h.status==='dead'?'×':'○'}</i></article>)}</div>}
      {tab==='timeline' && <div className="timeline">{['اختفاء كريم وبداية التحقيق.','ظهور أول تناقض في زمن الوفاة.','تكرار الوجوه نفسها بعد موت أصحابها.','المواجهة الأخيرة بين الناجين.'].map((text,i)=><div className={`timeline-row ${i+1<=cycle?'seen':''}`} key={i}><div className="timeline-dot">{i+1}</div><div><span>الليلة {i+1}</span><p>{text}</p></div></div>)}</div>}
      <footer className="board-foot"><span>تلميح</span><p>إذا تعارضت الشهادة مع دليل مادي، صدّق الدليل أولاً.</p></footer>
    </section>
  </div>
}
