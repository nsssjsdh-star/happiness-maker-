import React,{useState} from 'react'
import {useGameStore} from '../store/gameStore'
import './IntroScreen.css'

export function IntroScreen(){
 const [visible,setVisible]=useState(true); const {initSession}=useGameStore()
 if(!visible)return null
 return <div className="intro-overlay" dir="rtl">
   <div className="intro-photo"/>
   <div className="intro-shade"/>
   <main className="intro-card">
     <div className="intro-brand"><span className="brand-mark">HM</span><div><b>HAPPINESS MAKER</b><small>STORIES • MYSTERY • HORROR</small></div><span className="case-chip">ملف 001</span></div>
     <div className="intro-art"><img src="/assets/first-house.png" alt="مشهد من القضية"/><div className="art-label">قرية معزولة • بعد منتصف الليل</div></div>
     <div className="intro-copy">
       <p className="eyebrow">قضية تحقيق تفاعلية</p><h1>الوجه الأخير</h1>
       <p className="lead">في هذه القرية، قد ترى شخصاً تعرفه جيداً… لكنك لا تعرف من يقف خلف وجهه.</p>
       <div className="rule"><span/> <b>لا تثق بالوجه وحده</b> <span/></div>
       <p className="body">اختفى كريم، ثم بدأ السكان يرون أشخاصاً يفترض أنهم ماتوا. استجوبهم، افحص الأدلة، وانتبه إلى التغيّرات الصغيرة قبل أن تتخذ قرارك.</p>
     </div>
     <div className="intro-meta"><span><b>04</b> ليالٍ</span><span><b>06</b> شخصيات</span><span><b>01</b> حقيقة</span></div>
     <button className="start-button" onClick={()=>{initSession();setVisible(false)}}><span>ابدأ التحقيق</span><i>←</i></button>
     <div className="intro-foot"><span>تجربة محلية</span><span>بدون حساب</span><span>مناسبة للهاتف</span></div>
   </main>
 </div>
}
