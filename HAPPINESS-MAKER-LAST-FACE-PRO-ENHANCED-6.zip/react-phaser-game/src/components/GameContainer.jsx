import React,{useEffect,useRef} from 'react'
import {Game} from '../game/Game'
import {useGameStore} from '../store/gameStore'
import Sidebar from './Sidebar'
import './GameContainer.css'

export function GameContainer(){
 const {initSession,cycle}=useGameStore(); const ref=useRef(null); const gameRef=useRef(null)
 useEffect(()=>{initSession();if(ref.current&&!gameRef.current){gameRef.current=new Game('phaser-game-container');gameRef.current.init()}return()=>{gameRef.current?.destroy();gameRef.current=null}},[])
 return <div className="main-layout">
   <Sidebar/>
   <div className="game-wrapper">
     <div className="game-topbar"><div className="top-title"><span className="top-mark">HM</span><div><b>الوجه الأخير</b><small>ملف التحقيق 001</small></div></div><div className="top-night"><span>الليلة</span><b>0{cycle}</b><i>●</i></div></div>
     <div id="phaser-game-container" ref={ref} className="phaser-game"/>
     <div className="scene-fade"/>
     <div className="game-footer"><span>اسحب أو استخدم الأسهم</span><b>كل تفصيل قد يكون دليلاً</b><span>تحقيق محلي</span></div>
   </div>
 </div>
}
